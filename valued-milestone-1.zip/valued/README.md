# ValueD: Compare Smart. Buy Better.

A shopping comparison website for India, built with Next.js (App Router), TypeScript and Tailwind CSS.

> **Status: first milestone (foundation + catalogue).** The app runs entirely on clearly labelled **demo data**. There is no database, login, admin area, price alerts or AI assistant yet. See [Not built yet](#not-built-yet).

## What works now

| Feature | Works with demo data? | Needs an external service? |
| --- | --- | --- |
| Responsive homepage, navigation, mobile menu | Yes | No |
| Search by name, brand, model number, keyword (`/search?q=iphone`) | Yes | No |
| Category filter, sorting by comparable price, pagination | Yes | No |
| Product pages with variants, specs, similar products | Yes | No |
| Offer comparison table (cards on mobile) | Yes | No |
| Price comparison engine and ranking with explanations | Yes | No |
| Safe outbound redirect (`/go/<offerId>`) | Yes (goes to example.com) | No |
| Sitemap, robots, metadata (indexing is OFF by default) | Yes | No |

Everything is demo data. The retailers are fictional, prices are invented, and "View deal" links go to `example.com`. **Do not present this data as real prices.**

## Run it locally (beginner guide)

1. Install **Node.js 20.11 or newer** from <https://nodejs.org> (the LTS version is fine). Check with `node -v`.
2. Open a terminal in this folder and install dependencies:
   ```bash
   npm install
   ```
3. Copy the example settings file:
   ```bash
   cp .env.example .env.local
   ```
   The defaults work as they are.
4. Start the site:
   ```bash
   npm run dev
   ```
5. Open <http://localhost:3000>.

### Useful commands

| Command | What it does |
| --- | --- |
| `npm run dev` | Start the development server |
| `npm test` | Run the unit tests (pricing, ranking, search, URL safety) |
| `npm run typecheck` | Check TypeScript types |
| `npm run lint` | Check code style and common mistakes |
| `npm run build` | Make the production build |
| `npm run check` | Run all of the above in order |

## How the code is organised

```
app/            Pages and routes (Next.js App Router)
components/     Reusable UI pieces (header, product card, offer table...)
lib/
  types.ts      The shapes of products, offers, discounts, etc.
  pricing.ts    Comparable total = listed + delivery - confirmed discounts
  matching.ts   Is this listing really the same model and configuration?
  ranking.ts    Ranks offers and explains the result
  freshness.ts  Sample / live / stale
  search.ts     Query validation, matching, sorting, pagination
  outbound.ts   Checks a retailer URL is safe before redirecting
  catalog.ts    The only file the pages read data from
  providers/    Data sources (sample today; Supabase and retailer feeds later)
  data/sample.ts  The demo catalogue
tests/          Automated tests
tailwind.config.ts  Colours and fonts (the design tokens)
```

## Key decisions, in plain language

- **Comparable price.** Only discounts that apply to everyone are subtracted. Bank, exchange and membership offers are shown next to the offer but never counted, because they depend on the buyer.
- **Unknown is not zero.** If delivery cost is unknown, the total is labelled incomplete rather than assuming free delivery.
- **The cheapest offer does not automatically win.** Listings for a different model or configuration, out-of-stock items, and refurbished items (by default) are left out of the ranking, and the page says so.
- **Providers.** All data comes through `lib/providers/types.ts`. To add a source, implement that interface and select it in `lib/catalog.ts`. Only use sources you are authorised to use. Do not scrape sites or bypass access controls.
- **No open redirects.** Product links go through `/go/<offerId>`. The server looks up the URL and checks it belongs to the retailer's own domain.
- **Indexing is off.** `NEXT_PUBLIC_ALLOW_INDEXING=false` stops search engines from indexing demo prices. Turn it on only with real data.
- **Dependency versions.** `package.json` uses version ranges chosen for compatibility (Next 15, React 19, Tailwind 3.4, ESLint 9). They were not installed in the environment this code was written in, so run `npm install` and `npm run check` first and fix anything the newest patch releases change.

## Not built yet

| Feature | Depends on |
| --- | --- |
| Persistent data, migrations, seed script | A Supabase project |
| Admin dashboard (`/admin/*`) | Supabase Auth, an admin role, server-side authorization |
| Sign up / sign in / account settings | Supabase Auth |
| Watchlist, price history, price alerts | Accounts, database, scheduled job, email provider |
| AI shopping assistant | Catalogue in the database, server-side LLM key, rate limiting |
| Review summaries | Licensed review data |
| Affiliate links and click tracking | Affiliate accounts, database |
| Live prices | An approved retailer API, affiliate feed or licensed data provider |
| Legal pages | Business details and review by a lawyer. The current text is a draft template |

## Tests

`npm test` runs 50+ tests covering price calculation, discount eligibility, missing delivery charges, product mismatch, ranking order and tie-breaks, freshness, search validation and matching, URL safety, and demo-data integrity. Tests for authentication, user-data isolation, admin authorization, price alerts and AI validation will be added with those features.
