import Link from "next/link";
import { DataBadge } from "./data-badge";
import { ProductThumb } from "./product-thumb";
import { buttonClasses } from "./ui/button";
import { formatCheckedAt, formatINR } from "@/lib/format";
import type { ProductSummary } from "@/lib/types";

export function ProductCard({ summary }: { summary: ProductSummary }) {
  const { product, bestOffer } = summary;
  return (
    <article className="flex flex-col rounded-xl border border-line bg-white p-4 shadow-card">
      <ProductThumb product={product} />
      <div className="mt-4 flex-1">
        <h3 className="text-lg font-semibold leading-snug">
          <Link href={`/product/${product.slug}`} className="hover:underline">
            {product.name}
          </Link>
        </h3>
        <p className="mt-1 text-sm text-muted">{product.brand}</p>
        <p className="text-sm text-muted">Model {product.modelNumber}</p>

        {bestOffer ? (
          <div className="mt-4">
            <p className="text-2xl font-bold text-forest">{formatINR(bestOffer.total.amount)}</p>
            <p className="text-sm text-muted">
              Best comparable price{bestOffer.total.isComplete ? "" : " (delivery unknown)"}
            </p>
            {bestOffer.total.appliedDiscountTotal > 0 ? (
              <p className="mt-1 text-sm text-brand-800">
                Includes {formatINR(bestOffer.total.appliedDiscountTotal)} confirmed discount
              </p>
            ) : null}
            <p className="mt-2 text-sm">at {bestOffer.retailer?.name ?? "retailer"}</p>
            <p className="text-xs text-muted">Checked {formatCheckedAt(bestOffer.offer.lastCheckedAt)}</p>
            <div className="mt-2">
              <DataBadge status={bestOffer.freshness.status} />
            </div>
          </div>
        ) : (
          <p className="mt-4 text-sm text-muted">No eligible offer is recorded right now.</p>
        )}
      </div>

      <div className="mt-4 flex gap-2">
        {bestOffer ? (
          // A plain <a>, not <Link>: /go redirects off-site, so it must not be prefetched.
          <a
            href={`/go/${bestOffer.offer.id}`}
            target="_blank"
            rel="sponsored nofollow noopener noreferrer"
            className={buttonClasses("primary", "md", "flex-1")}
          >
            View deal
            <span className="sr-only">
              {" "}
              for {product.name} at {bestOffer.retailer?.name} (opens in a new tab)
            </span>
          </a>
        ) : null}
        <Link href={`/product/${product.slug}`} className={buttonClasses("secondary", "md", bestOffer ? "" : "flex-1")}>
          Compare
          <span className="sr-only"> offers for {product.name}</span>
        </Link>
      </div>
    </article>
  );
}
