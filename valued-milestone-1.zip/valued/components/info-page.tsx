import type { ReactNode } from "react";

export function InfoPage({ title, draft = false, children }: { title: string; draft?: boolean; children: ReactNode }) {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="text-3xl font-bold sm:text-4xl">{title}</h1>
      {draft ? (
        <p role="note" className="mt-4 rounded-lg border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-950">
          Draft template. This text has not been reviewed by a lawyer and must be reviewed and completed before launch.
        </p>
      ) : null}
      <div className="mt-6 space-y-4 leading-relaxed text-ink-soft [&_h2]:mt-8 [&_h2]:text-xl [&_h2]:font-semibold [&_ul]:list-disc [&_ul]:space-y-1 [&_ul]:pl-5">{children}</div>
    </div>
  );
}
