import { CategoryIcon } from "./category-icon";
import type { Product } from "@/lib/types";

/** Stand-in until real product images are licensed. Uses an icon rather than a fake photo. */
export function ProductThumb({ product, className = "h-36" }: { product: Product; className?: string }) {
  return (
    <div role="img" aria-label={`${product.name}, product photo not available yet`} className={`flex items-center justify-center rounded-lg bg-mint-100 text-brand-700 ${className}`}>
      <CategoryIcon slug={product.categorySlug} className="h-12 w-12" />
    </div>
  );
}
