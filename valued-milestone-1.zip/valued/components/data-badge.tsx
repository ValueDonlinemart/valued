import type { DataStatus } from "@/lib/types";

const STYLES: Record<DataStatus, { label: string; cls: string; title: string }> = {
  sample: { label: "Demo data", cls: "bg-amber-50 text-amber-900 border-amber-300", title: "Illustrative price, not a live offer" },
  live: { label: "Live", cls: "bg-brand-50 text-brand-800 border-brand-200", title: "Recently checked with the retailer" },
  stale: { label: "Not recently checked", cls: "bg-stone-100 text-stone-800 border-stone-300", title: "This price may be out of date" },
  unavailable: { label: "Source unavailable", cls: "bg-red-50 text-red-900 border-red-300", title: "The data source could not be reached" },
};

export function DataBadge({ status }: { status: DataStatus }) {
  const s = STYLES[status];
  return (
    <span title={s.title} className={`inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium ${s.cls}`}>
      {s.label}
    </span>
  );
}
