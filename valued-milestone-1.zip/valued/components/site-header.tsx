"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Menu, Search, X } from "lucide-react";
import { Logo } from "./logo";
import { buttonClasses } from "./ui/button";

const NAV = [
  { href: "/", label: "Home" },
  { href: "/products", label: "Products" },
  { href: "/deals", label: "Deals" },
  { href: "/price-tracker", label: "Price Tracker", soon: true },
  { href: "/ai-assistant", label: "AI Assistant", soon: true },
];

function isActive(pathname: string, href: string): boolean {
  if (href === "/") return pathname === "/";
  if (href === "/products") return pathname.startsWith("/products") || pathname.startsWith("/product/") || pathname.startsWith("/search");
  return pathname === href || pathname.startsWith(`${href}/`);
}

export function SiteHeader() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const buttonRef = useRef<HTMLButtonElement>(null);

  // Close the mobile menu after navigating.
  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  // Escape closes the menu and returns focus to the toggle button.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        buttonRef.current?.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  const linkCls = (active: boolean) =>
    `rounded-md px-3 py-2 text-sm font-medium ${active ? "bg-mint-100 text-forest" : "text-ink-soft hover:bg-mint"}`;

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-white">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <Logo />

        <nav aria-label="Main" className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) => (
            <Link key={item.href} href={item.href} aria-current={isActive(pathname, item.href) ? "page" : undefined} className={linkCls(isActive(pathname, item.href))}>
              {item.label}
              {item.soon ? <span className="ml-1.5 rounded bg-amber-100 px-1.5 py-0.5 text-xs text-amber-900">Soon</span> : null}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Link href="/search" className="inline-flex h-11 w-11 items-center justify-center rounded-lg text-ink-soft hover:bg-mint-100">
            <Search className="h-5 w-5" aria-hidden="true" />
            <span className="sr-only">Search products</span>
          </Link>
          <Link href="/sign-in" className={buttonClasses("ghost", "md", "hidden sm:inline-flex")}>Sign In</Link>
          <Link href="/sign-up" className={buttonClasses("primary", "md", "hidden sm:inline-flex")}>Join Free</Link>
          <button
            ref={buttonRef}
            type="button"
            className="inline-flex h-11 w-11 items-center justify-center rounded-lg text-ink-soft hover:bg-mint-100 lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => setOpen((o) => !o)}
          >
            {open ? <X className="h-6 w-6" aria-hidden="true" /> : <Menu className="h-6 w-6" aria-hidden="true" />}
            <span className="sr-only">{open ? "Close menu" : "Open menu"}</span>
          </button>
        </div>
      </div>

      <div id="mobile-menu" hidden={!open} className="border-t border-line bg-white lg:hidden">
        <nav aria-label="Mobile" className="mx-auto flex max-w-7xl flex-col gap-1 px-4 py-3 sm:px-6">
          {NAV.map((item) => (
            <Link key={item.href} href={item.href} aria-current={isActive(pathname, item.href) ? "page" : undefined} className={`${linkCls(isActive(pathname, item.href))} py-3 text-base`}>
              {item.label}
              {item.soon ? <span className="ml-2 rounded bg-amber-100 px-1.5 py-0.5 text-xs text-amber-900">Coming soon</span> : null}
            </Link>
          ))}
          <div className="mt-2 flex gap-2 sm:hidden">
            <Link href="/sign-in" className={buttonClasses("secondary", "md", "flex-1")}>Sign In</Link>
            <Link href="/sign-up" className={buttonClasses("primary", "md", "flex-1")}>Join Free</Link>
          </div>
        </nav>
      </div>
    </header>
  );
}
