import Link from "next/link";
import type { ComponentProps } from "react";

const base =
  "inline-flex items-center justify-center gap-2 rounded-lg font-semibold transition-colors disabled:opacity-60";
const variants = {
  primary: "bg-brand-700 text-white hover:bg-brand-800",
  secondary: "border border-brand-700 bg-white text-brand-800 hover:bg-brand-50",
  ghost: "text-ink hover:bg-mint-100",
  onDark: "bg-white text-forest hover:bg-brand-100",
} as const;
const sizes = { sm: "h-9 px-3 text-sm", md: "h-11 px-4 text-sm", lg: "h-12 px-6 text-base" } as const;

export type ButtonVariant = keyof typeof variants;
export type ButtonSize = keyof typeof sizes;

export function buttonClasses(variant: ButtonVariant = "primary", size: ButtonSize = "md", extra = ""): string {
  return `${base} ${variants[variant]} ${sizes[size]} ${extra}`.trim();
}

type ButtonLinkProps = ComponentProps<typeof Link> & { variant?: ButtonVariant; size?: ButtonSize };

/** An internal link that looks like a button. */
export function ButtonLink({ variant, size, className = "", ...props }: ButtonLinkProps) {
  return <Link {...props} className={buttonClasses(variant, size, className)} />;
}
