import { ButtonLink } from "./ui/button";

export function ComingSoon({ title, summary, needs }: { title: string; summary: string; needs: string[] }) {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
      <p className="inline-block rounded-full border border-amber-300 bg-amber-50 px-3 py-1 text-sm font-medium text-amber-950">Coming soon</p>
      <h1 className="mt-4 text-3xl font-bold sm:text-4xl">{title}</h1>
      <p className="mt-4 text-lg text-ink-soft">{summary}</p>
      <h2 className="mt-8 text-xl font-semibold">What it needs before it can launch</h2>
      <ul className="mt-3 list-disc space-y-1 pl-5 text-ink-soft">{needs.map((n) => <li key={n}>{n}</li>)}</ul>
      <div className="mt-8 flex gap-3">
        <ButtonLink href="/products" variant="primary">Browse products</ButtonLink>
        <ButtonLink href="/" variant="secondary">Back to home</ButtonLink>
      </div>
    </div>
  );
}
