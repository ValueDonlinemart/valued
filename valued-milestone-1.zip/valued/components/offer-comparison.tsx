import { DataBadge } from "./data-badge";
import { buttonClasses } from "./ui/button";
import { formatCheckedAt, formatINR } from "@/lib/format";
import type { Availability, RankedOffer } from "@/lib/types";

const AVAILABILITY: Record<Availability, string> = {
  in_stock: "In stock",
  low_stock: "Low stock",
  preorder: "Pre-order",
  out_of_stock: "Out of stock",
  unknown: "Availability unknown",
};
const CONDITION: Record<string, string> = { new: "New", open_box: "Open box", refurbished: "Refurbished", used: "Used" };

function DealLink({ r, productName, label = "View deal", primary = true }: { r: RankedOffer; productName: string; label?: string; primary?: boolean }) {
  return (
    // A plain <a>: /go redirects off-site, so it must not be prefetched. "sponsored" is correct once affiliate links are used.
    <a
      href={`/go/${r.offer.id}`}
      target="_blank"
      rel="sponsored nofollow noopener noreferrer"
      className={primary ? buttonClasses("primary", "md") : "font-medium text-brand-800 underline underline-offset-4"}
    >
      {label}
      <span className="sr-only"> for {productName} at {r.retailer?.name ?? "retailer"} (opens in a new tab)</span>
    </a>
  );
}

function Conditional({ r }: { r: RankedOffer }) {
  if (r.total.conditionalDiscounts.length === 0) return <span className="text-muted">None recorded</span>;
  return (
    <ul className="space-y-1">
      {r.total.conditionalDiscounts.map((d) => (
        <li key={d.id} className="text-xs">
          <span className="font-medium">{d.label}: {formatINR(d.amount)} off</span>
          <br />
          <span className="text-muted">{d.condition}. Not included in the total.</span>
        </li>
      ))}
    </ul>
  );
}

function Total({ r }: { r: RankedOffer }) {
  return (
    <div>
      <span className="text-lg font-bold text-forest">{formatINR(r.total.amount)}</span>
      {!r.total.isComplete ? <p className="text-xs font-medium text-amber-900">Incomplete: delivery unknown</p> : null}
    </div>
  );
}

const delivery = (r: RankedOffer) =>
  r.total.shippingAmount === null ? "Unknown" : r.total.shippingAmount === 0 ? "Free" : formatINR(r.total.shippingAmount);
const confirmed = (r: RankedOffer) =>
  r.total.appliedDiscountTotal > 0 ? `${formatINR(r.total.appliedDiscountTotal)} off` : "None confirmed";

export function OfferComparison({ ranked, productName }: { ranked: RankedOffer[]; productName: string }) {
  const eligible = ranked.filter((r) => r.eligible);
  const excluded = ranked.filter((r) => !r.eligible);

  if (eligible.length === 0) {
    return <p className="rounded-lg border border-line bg-mint p-4 text-sm">No eligible offers are recorded for this configuration.</p>;
  }

  return (
    <div className="space-y-8">
      {/* Wide screens: table */}
      <div className="hidden overflow-x-auto rounded-xl border border-line md:block">
        <table className="w-full min-w-[56rem] border-collapse text-left text-sm">
          <caption className="sr-only">Offers for {productName}, ranked from best to worst</caption>
          <thead className="bg-mint text-ink-soft">
            <tr>
              {["Retailer", "Listed price", "Delivery", "Confirmed discounts", "Conditional offers", "Comparable total", "Availability", "Last checked", "Action"].map((h) => (
                <th key={h} scope="col" className="px-3 py-3 font-semibold">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {eligible.map((r) => (
              <tr key={r.offer.id} className={r.rank === 1 ? "bg-brand-50" : ""}>
                <th scope="row" className="px-3 py-3 align-top font-medium">
                  {r.retailer?.name}
                  {r.rank === 1 ? <p className="text-xs font-medium text-brand-800">Top ranked</p> : null}
                  {r.offer.sellerName ? <p className="text-xs font-normal text-muted">Seller: {r.offer.sellerName}</p> : null}
                  <p className="text-xs font-normal text-muted">{r.match.level === "exact" ? "Exact model match" : "Model not confirmed"}</p>
                </th>
                <td className="px-3 py-3 align-top">{formatINR(r.total.listedPrice)}</td>
                <td className="px-3 py-3 align-top">{delivery(r)}</td>
                <td className="px-3 py-3 align-top">{confirmed(r)}</td>
                <td className="px-3 py-3 align-top"><Conditional r={r} /></td>
                <td className="px-3 py-3 align-top"><Total r={r} /></td>
                <td className="px-3 py-3 align-top">
                  {AVAILABILITY[r.offer.availability]}
                  <p className="text-xs text-muted">{CONDITION[r.offer.condition]}{r.offer.warranty ? `, ${r.offer.warranty}` : ", warranty not stated"}</p>
                </td>
                <td className="px-3 py-3 align-top">
                  <p className="text-xs">{formatCheckedAt(r.offer.lastCheckedAt)}</p>
                  <DataBadge status={r.freshness.status} />
                </td>
                <td className="px-3 py-3 align-top"><DealLink r={r} productName={productName} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Small screens: cards */}
      <ul className="space-y-4 md:hidden">
        {eligible.map((r) => (
          <li key={r.offer.id} className={`rounded-xl border p-4 ${r.rank === 1 ? "border-brand-700 bg-brand-50" : "border-line bg-white"}`}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-base font-semibold">{r.retailer?.name}</h3>
                {r.rank === 1 ? <p className="text-xs font-medium text-brand-800">Top ranked</p> : null}
                <p className="text-xs text-muted">{r.match.level === "exact" ? "Exact model match" : "Model not confirmed"}</p>
              </div>
              <Total r={r} />
            </div>
            <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-2 text-sm">
              <dt className="text-muted">Listed price</dt><dd>{formatINR(r.total.listedPrice)}</dd>
              <dt className="text-muted">Delivery</dt><dd>{delivery(r)}</dd>
              <dt className="text-muted">Confirmed discounts</dt><dd>{confirmed(r)}</dd>
              <dt className="text-muted">Availability</dt><dd>{AVAILABILITY[r.offer.availability]}</dd>
              <dt className="text-muted">Condition</dt><dd>{CONDITION[r.offer.condition]}</dd>
              <dt className="text-muted">Warranty</dt><dd>{r.offer.warranty ?? "Not stated"}</dd>
              <dt className="text-muted">Last checked</dt><dd>{formatCheckedAt(r.offer.lastCheckedAt)}</dd>
            </dl>
            <div className="mt-3"><p className="mb-1 text-sm text-muted">Conditional offers</p><Conditional r={r} /></div>
            <div className="mt-3 flex items-center justify-between gap-3">
              <DataBadge status={r.freshness.status} />
              <DealLink r={r} productName={productName} />
            </div>
          </li>
        ))}
      </ul>

      {excluded.length > 0 ? (
        <section aria-labelledby="not-ranked">
          <h3 id="not-ranked" className="text-lg font-semibold">Listings not ranked</h3>
          <p className="mt-1 text-sm text-muted">These are left out of the ranking, even when their price looks lower, so the best offer is a fair one.</p>
          <ul className="mt-3 divide-y divide-line rounded-xl border border-line">
            {excluded.map((r) => (
              <li key={r.offer.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
                <div>
                  <p className="font-medium">{r.retailer?.name ?? "Unknown retailer"}, {formatINR(r.total.amount)}</p>
                  <p className="text-muted">{r.exclusionReasons.join(" ")}</p>
                </div>
                <DealLink r={r} productName={productName} label="View listing" primary={false} />
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
