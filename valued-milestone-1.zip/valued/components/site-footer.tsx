import Link from "next/link";
import { Logo } from "./logo";
import { VERIFY_NOTICE } from "@/lib/constants";

const LINKS = [
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
  { href: "/privacy", label: "Privacy Policy" },
  { href: "/terms", label: "Terms" },
  { href: "/affiliate-disclosure", label: "Affiliate Disclosure" },
];

export function SiteFooter() {
  return (
    <footer className="on-dark mt-20 bg-forest text-brand-100">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-[1fr_auto]">
        <div>
          <Logo onDark />
          <p className="mt-3 text-sm font-medium text-white">Compare Smart. Buy Better.</p>
          <p className="mt-3 max-w-prose text-sm">{VERIFY_NOTICE}</p>
        </div>
        <nav aria-label="Footer">
          <ul className="space-y-2 text-sm">
            {LINKS.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="text-white underline-offset-4 hover:underline">{l.label}</Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
      <div className="border-t border-white/10 px-4 py-4 text-center text-xs sm:px-6">
        ValueD is a prototype. Business and legal details will be added before launch.
      </div>
    </footer>
  );
}
