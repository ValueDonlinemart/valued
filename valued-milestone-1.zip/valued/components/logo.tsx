import Link from "next/link";

export function Logo({ onDark = false }: { onDark?: boolean }) {
  return (
    <Link href="/" className="inline-flex items-center gap-2" aria-label="ValueD, go to the homepage">
      <svg width="30" height="30" viewBox="0 0 32 32" aria-hidden="true">
        <rect width="32" height="32" rx="8" fill={onDark ? "#10b981" : "#0b3d2e"} />
        <path d="M8 11l8 12 8-12" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M12.5 15.5l3.5 5 8-9.5" fill="none" stroke={onDark ? "#0b3d2e" : "#34d399"} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <span className={`font-display text-xl font-bold tracking-tight ${onDark ? "text-white" : "text-forest"}`}>ValueD</span>
    </Link>
  );
}
