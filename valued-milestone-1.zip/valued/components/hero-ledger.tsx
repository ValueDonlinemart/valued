import { DataBadge } from "./data-badge";
import { describeBreakdown, formatINR } from "@/lib/format";
import { DEMO_NOTICE } from "@/lib/constants";
import type { Product, RankedOffer } from "@/lib/types";

/**
 * The hero visual: a worked example of how ValueD arrives at a comparable price.
 * It is built from the same engine and data as the product pages, so it never shows invented numbers.
 */
export function HeroLedger({ product, variantLabel, ranked }: { product: Product; variantLabel: string | null; ranked: RankedOffer[] }) {
  const eligible = ranked.filter((r) => r.eligible).slice(0, 3);
  const excluded = ranked.filter((r) => !r.eligible).slice(0, 2);
  const top = eligible[0];
  const conditional = top?.total.conditionalDiscounts[0];

  return (
    <figure aria-label={`Example comparison for ${product.name}`} className="rounded-2xl border border-line bg-white shadow-card">
      <figcaption className="flex items-start justify-between gap-3 border-b border-line px-5 py-4">
        <div>
          <p className="font-display text-lg font-semibold text-forest">{product.name}</p>
          {variantLabel ? <p className="text-sm text-muted">{variantLabel}</p> : null}
        </div>
        <DataBadge status="sample" />
      </figcaption>

      <ol className="divide-y divide-line">
        {eligible.map((r, i) => (
          <li key={r.offer.id} className={`px-5 py-3 ${i === 0 ? "border-l-4 border-brand-700 bg-brand-50" : "border-l-4 border-transparent"}`}>
            <div className="flex items-baseline justify-between gap-3">
              <span className="font-medium">{r.retailer?.name}</span>
              <span className="text-lg font-bold text-forest">{formatINR(r.total.amount)}</span>
            </div>
            <p className="mt-0.5 text-xs text-muted">{describeBreakdown(r.total)}</p>
            {i === 0 ? <p className="mt-1 text-xs font-medium text-brand-800">Lowest comparable total for this exact model</p> : null}
          </li>
        ))}
      </ol>

      {conditional ? (
        <p className="border-t border-line px-5 py-3 text-xs text-muted">
          {conditional.label} of {formatINR(conditional.amount)} at {top?.retailer?.name} is not counted. {conditional.condition}.
        </p>
      ) : null}

      {excluded.length > 0 ? (
        <div className="border-t border-line bg-mint px-5 py-3">
          <p className="text-xs font-medium text-ink-soft">Cheaper listings that were not ranked</p>
          <ul className="mt-1 space-y-1 text-xs text-muted">
            {excluded.map((r) => (
              <li key={r.offer.id}>
                {r.retailer?.name}, {formatINR(r.total.amount)}: {r.exclusionReasons[0]}
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <p className="border-t border-line px-5 py-3 text-xs text-amber-950">{DEMO_NOTICE}</p>
    </figure>
  );
}
