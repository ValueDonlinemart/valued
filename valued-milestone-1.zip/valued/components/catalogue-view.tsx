import Link from "next/link";
import { ProductCard } from "./product-card";
import { SearchForm } from "./search-form";
import { SourceNotice } from "./source-notice";
import { buttonClasses } from "./ui/button";
import { getCategories, getDataSourceStatus, getProductSummaries } from "@/lib/catalog";
import { POPULAR_SEARCHES } from "@/lib/constants";
import { buildSearchHref, parseSearchParams, searchCatalogue, SORT_LABELS, SORT_OPTIONS } from "@/lib/search";

type Raw = Record<string, string | string[] | undefined>;

/** Shared by /search and /products: filters, sorting, results and pagination, all driven by the URL. */
export async function CatalogueView({ basePath, rawParams, requireQuery }: { basePath: string; rawParams: Raw; requireQuery: boolean }) {
  const [categories, summaries, status] = await Promise.all([getCategories(), getProductSummaries(), getDataSourceStatus()]);
  const { params, errors, notices } = parseSearchParams(rawParams, categories.map((c) => c.slug));
  const categoryName = categories.find((c) => c.slug === params.category)?.name;

  const waitingForQuery = requireQuery && !params.q && errors.length === 0;
  const result = waitingForQuery || errors.length > 0 ? null : searchCatalogue(summaries, params);

  const heading = params.q ? `Results for "${params.q}"` : categoryName ?? (requireQuery ? "Search products" : "All products");

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <h1 className="text-3xl font-bold sm:text-4xl">{heading}</h1>

      <div className="mt-5 max-w-2xl">
        <SearchForm id="catalogue-search" defaultValue={params.q ?? ""} category={params.category} action={basePath === "/products" ? "/products" : "/search"} />
      </div>

      {errors.length > 0 ? (
        <div role="alert" className="mt-4 max-w-2xl rounded-lg border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-900">
          {errors.map((e) => <p key={e}>{e}</p>)}
        </div>
      ) : null}
      {notices.map((n) => (
        <p key={n} role="status" className="mt-4 text-sm text-muted">{n}</p>
      ))}

      <nav aria-label="Categories" className="mt-6 flex flex-wrap gap-2">
        <Link href={buildSearchHref(basePath, params, { category: null, page: 1 })} aria-current={!params.category ? "true" : undefined} className={chip(!params.category)}>All</Link>
        {categories.map((c) => (
          <Link key={c.slug} href={buildSearchHref(basePath, params, { category: c.slug, page: 1 })} aria-current={params.category === c.slug ? "true" : undefined} className={chip(params.category === c.slug)}>
            {c.name}
          </Link>
        ))}
      </nav>

      <div className="mt-5"><SourceNotice status={status} /></div>

      {waitingForQuery ? (
        <section className="mt-8">
          <p className="text-muted">Enter a product name, brand or model number, or try a popular search.</p>
          <ul className="mt-4 flex flex-wrap gap-2">
            {POPULAR_SEARCHES.map((s) => (
              <li key={s}><Link href={`/search?q=${encodeURIComponent(s)}`} className={buttonClasses("secondary", "sm")}>{s}</Link></li>
            ))}
          </ul>
        </section>
      ) : null}

      {result ? (
        <section className="mt-8" aria-label="Results">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p role="status" aria-live="polite" className="text-sm text-muted">
              {result.total} {result.total === 1 ? "product" : "products"}
            </p>
            <form action={basePath} method="get" className="flex items-center gap-2">
              {params.q ? <input type="hidden" name="q" value={params.q} /> : null}
              {params.category ? <input type="hidden" name="category" value={params.category} /> : null}
              <label htmlFor="sort" className="text-sm text-muted">Sort by</label>
              <select id="sort" name="sort" defaultValue={params.sort} className="h-10 rounded-lg border border-line bg-white px-2 text-sm">
                {SORT_OPTIONS.map((o) => <option key={o} value={o}>{SORT_LABELS[o]}</option>)}
              </select>
              <button type="submit" className={buttonClasses("secondary", "sm")}>Apply</button>
            </form>
          </div>

          {result.total === 0 ? (
            <div className="mt-8 rounded-xl border border-line bg-mint p-6">
              <h2 className="text-xl font-semibold">No products match{params.q ? ` "${params.q}"` : ""}</h2>
              <p className="mt-2 text-sm text-muted">Check the spelling, try a brand or model number, or browse a category above.</p>
            </div>
          ) : (
            <ul className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {result.items.map((s) => <li key={s.product.id} className="flex"><div className="flex-1"><ProductCard summary={s} /></div></li>)}
            </ul>
          )}

          {result.pageCount > 1 ? (
            <nav aria-label="Pagination" className="mt-8 flex items-center justify-center gap-4">
              {result.page > 1 ? <Link href={buildSearchHref(basePath, params, { page: result.page - 1 })} rel="prev" className={buttonClasses("secondary", "md")}>Previous</Link> : null}
              <span className="text-sm text-muted">Page {result.page} of {result.pageCount}</span>
              {result.page < result.pageCount ? <Link href={buildSearchHref(basePath, params, { page: result.page + 1 })} rel="next" className={buttonClasses("secondary", "md")}>Next</Link> : null}
            </nav>
          ) : null}
        </section>
      ) : null}
    </div>
  );
}

const chip = (active: boolean) =>
  `rounded-full border px-3 py-1.5 text-sm font-medium ${active ? "border-brand-700 bg-brand-700 text-white" : "border-line bg-white text-ink-soft hover:bg-mint-100"}`;
