import { Headphones, Laptop, Plug, Smartphone, Tv, Watch, type LucideIcon } from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  smartphones: Smartphone,
  laptops: Laptop,
  headphones: Headphones,
  smartwatches: Watch,
  "tvs-entertainment": Tv,
  "home-appliances": Plug,
};

export function CategoryIcon({ slug, className = "h-6 w-6" }: { slug: string; className?: string }) {
  const Icon = ICONS[slug] ?? Plug;
  return <Icon className={className} aria-hidden="true" />;
}
