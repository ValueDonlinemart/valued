import { buttonClasses } from "./ui/button";

interface Props {
  id: string;
  defaultValue?: string;
  category?: string | null;
  action?: string;
  size?: "md" | "lg";
}

/** A plain GET form: it works without JavaScript and keeps the query in the URL. */
export function SearchForm({ id, defaultValue = "", category = null, action = "/search", size = "md" }: Props) {
  return (
    <form action={action} method="get" role="search" className="flex w-full gap-2">
      <label htmlFor={id} className="sr-only">
        Search products by name, brand or model number
      </label>
      <input
        id={id}
        name="q"
        type="search"
        required
        minLength={2}
        maxLength={100}
        defaultValue={defaultValue}
        placeholder="Search products, brands or model numbers"
        className={`min-w-0 flex-1 rounded-lg border border-line bg-white px-4 text-ink placeholder:text-muted ${size === "lg" ? "h-12 text-base" : "h-11 text-sm"}`}
      />
      {category ? <input type="hidden" name="category" value={category} /> : null}
      <button type="submit" className={buttonClasses("primary", size)}>
        Search
      </button>
    </form>
  );
}
