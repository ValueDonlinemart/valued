import { DEMO_NOTICE } from "@/lib/constants";
import { formatCheckedAt } from "@/lib/format";
import type { DataSourceStatus } from "@/lib/types";
import { Info } from "lucide-react";

/** Tells visitors what kind of data they are looking at. Never hidden for demo data. */
export function SourceNotice({ status }: { status: DataSourceStatus }) {
  if (status.status === "live") return null;
  const text =
    status.status === "sample"
      ? DEMO_NOTICE
      : status.status === "stale"
        ? `Some prices have not been checked recently${status.lastCheckedAt ? ` (last checked ${formatCheckedAt(status.lastCheckedAt)})` : ""}. Confirm on the retailer's site.`
        : "Live prices are temporarily unavailable.";
  return (
    <p role="note" className="flex items-start gap-2 rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-950">
      <Info className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
      <span>{text}</span>
    </p>
  );
}
