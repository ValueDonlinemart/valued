import type { ComparableTotal } from "./types";

const inr = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export function formatINR(amount: number): string {
  return inr.format(amount);
}

const dateTime = new Intl.DateTimeFormat("en-IN", {
  dateStyle: "medium",
  timeStyle: "short",
  timeZone: "Asia/Kolkata",
});

/** Formats an ISO timestamp for display in Indian Standard Time. */
export function formatCheckedAt(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "Unknown";
  return `${dateTime.format(d)} IST`;
}

/** One-line explanation of how a comparable total was reached, e.g. "₹65,900 + free delivery - ₹1,000 discount". */
export function describeBreakdown(total: ComparableTotal): string {
  const parts = [formatINR(total.listedPrice)];
  if (total.shippingAmount === null) parts.push("+ delivery unknown");
  else if (total.shippingAmount === 0) parts.push("+ free delivery");
  else parts.push(`+ ${formatINR(total.shippingAmount)} delivery`);
  if (total.appliedDiscountTotal > 0) parts.push(`- ${formatINR(total.appliedDiscountTotal)} confirmed discount`);
  return parts.join(" ");
}
