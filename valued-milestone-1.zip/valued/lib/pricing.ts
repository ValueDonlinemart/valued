import type { ComparableTotal, Offer } from "./types";

function isValidAmount(n: unknown): n is number {
  return typeof n === "number" && Number.isFinite(n) && n >= 0;
}

const round2 = (n: number) => Math.round(n * 100) / 100;

/**
 * Comparable total = listed price + known mandatory delivery - confirmed discounts.
 *
 * Rules:
 * - Only discounts marked "confirmed" are subtracted. Conditional ones (bank, exchange,
 *   membership...) are returned separately and never applied automatically.
 * - Unknown delivery is NOT treated as zero. The total is flagged incomplete instead.
 * - The total never drops below zero.
 */
export function calculateComparableTotal(
  offer: Pick<Offer, "listedPrice" | "shipping" | "discounts">,
): ComparableTotal {
  if (!isValidAmount(offer.listedPrice)) {
    throw new RangeError("listedPrice must be a finite number that is 0 or more");
  }

  const notes: string[] = [];
  let shippingAmount: number | null;
  switch (offer.shipping.status) {
    case "free":
      shippingAmount = 0;
      break;
    case "paid":
      if (isValidAmount(offer.shipping.amount)) {
        shippingAmount = offer.shipping.amount;
      } else {
        shippingAmount = null;
        notes.push("The recorded delivery charge is invalid, so it is treated as unknown.");
      }
      break;
    case "unknown":
      shippingAmount = null;
      break;
  }
  const isComplete = shippingAmount !== null;
  if (!isComplete) {
    notes.push("Delivery charge is unknown, so the real total may be higher.");
  }

  const appliedDiscounts = [];
  const conditionalDiscounts = [];
  for (const d of offer.discounts) {
    if (!isValidAmount(d.amount) || d.amount === 0) {
      notes.push(`Ignored discount "${d.label}" because its amount is not valid.`);
      continue;
    }
    if (d.eligibility === "confirmed") appliedDiscounts.push(d);
    else conditionalDiscounts.push(d);
  }

  const appliedDiscountTotal = round2(appliedDiscounts.reduce((sum, d) => sum + d.amount, 0));
  const gross = offer.listedPrice + (shippingAmount ?? 0);
  if (appliedDiscountTotal > gross) {
    notes.push("Confirmed discounts exceed the price, so the total is shown as zero.");
  }

  return {
    amount: round2(Math.max(0, gross - appliedDiscountTotal)),
    isComplete,
    listedPrice: offer.listedPrice,
    shippingAmount,
    appliedDiscounts,
    appliedDiscountTotal,
    conditionalDiscounts,
    notes,
  };
}
