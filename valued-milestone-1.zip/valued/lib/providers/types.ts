import type { Category, DataSourceStatus, Offer, Product, Retailer } from "../types";

/**
 * Every data source (sample data, Supabase, an approved retailer API, an affiliate feed...)
 * implements this interface, so sources can be added without touching the UI.
 *
 * Only add providers you are authorised to use. Do not scrape sites or bypass access controls.
 */
export interface CatalogProvider {
  id: string;
  label: string;
  getCategories(): Promise<Category[]>;
  getProducts(): Promise<Product[]>;
  getRetailers(): Promise<Retailer[]>;
  getOffers(): Promise<Offer[]>;
  getStatus(now: Date): Promise<DataSourceStatus>;
}
