import {
  SAMPLE_SNAPSHOT_AT,
  sampleCategories,
  sampleOffers,
  sampleProducts,
  sampleRetailers,
} from "../data/sample";
import type { CatalogProvider } from "./types";

export const sampleProvider: CatalogProvider = {
  id: "sample",
  label: "Demo data",
  getCategories: async () => sampleCategories,
  getProducts: async () => sampleProducts,
  getRetailers: async () => sampleRetailers,
  getOffers: async () => sampleOffers,
  getStatus: async () => ({
    id: "sample",
    label: "Demo data",
    status: "sample",
    lastCheckedAt: SAMPLE_SNAPSHOT_AT,
    message: "Demo data. Prices are illustrative and are not live offers.",
  }),
};
