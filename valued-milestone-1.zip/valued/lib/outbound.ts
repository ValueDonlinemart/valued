/**
 * Validates a retailer URL before we redirect a visitor to it.
 * Returns the normalised URL, or null when it is not safe.
 *
 * Safe means: https, no embedded credentials, default port, and the host is exactly one of the
 * allowed retailer hosts or a subdomain of one. Lookalikes such as "example.com.evil.net" fail.
 */
export function getSafeOutboundUrl(rawUrl: string, allowedBaseUrls: string[]): string | null {
  let url: URL;
  try {
    url = new URL(rawUrl);
  } catch {
    return null;
  }
  if (url.protocol !== "https:") return null;
  if (url.username || url.password) return null;
  if (url.port && url.port !== "443") return null;

  const host = url.hostname.toLowerCase();
  const allowedHosts: string[] = [];
  for (const base of allowedBaseUrls) {
    try {
      allowedHosts.push(new URL(base).hostname.toLowerCase());
    } catch {
      // Ignore malformed allow-list entries rather than allowing everything.
    }
  }
  const ok = allowedHosts.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
  return ok ? url.toString() : null;
}
