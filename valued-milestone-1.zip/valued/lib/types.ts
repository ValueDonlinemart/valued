// Shared domain types. Prices are whole or decimal rupees (INR).

export type CurrencyCode = "INR";
export type SourceType = "sample" | "live" | "affiliate_feed" | "admin";
export type Availability = "in_stock" | "low_stock" | "preorder" | "out_of_stock" | "unknown";
export type Condition = "new" | "open_box" | "refurbished" | "used";

/** Delivery cost with an explicit unknown state. Unknown is never treated as zero. */
export type Shipping =
  | { status: "free" }
  | { status: "paid"; amount: number }
  | { status: "unknown" };

export type DiscountKind = "instant" | "coupon" | "bank" | "exchange" | "membership";

export interface Discount {
  id: string;
  label: string;
  kind: DiscountKind;
  amount: number;
  /** "confirmed" applies to every buyer. "conditional" depends on the buyer and is never auto-applied. */
  eligibility: "confirmed" | "conditional";
  /** Plain-language condition, shown to users for conditional discounts. */
  condition?: string;
}

export interface Category {
  id: string;
  slug: string;
  name: string;
  description: string;
}

export interface ProductVariant {
  id: string;
  label: string;
  attributes: Record<string, string>;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  brand: string;
  modelNumber: string;
  categorySlug: string;
  description: string;
  specifications: Record<string, string>;
  keywords: string[];
  imageUrl: string | null;
  variants: ProductVariant[];
}

export interface Retailer {
  id: string;
  name: string;
  baseUrl: string;
  integrationType: "sample" | "api" | "affiliate_feed" | "manual";
  status: "active" | "paused";
  /** Used only as a ranking tie-breaker. Never displayed as a trust badge unless backed by real data. */
  verified: boolean;
}

export interface Offer {
  id: string;
  productId: string;
  /** Which variant this listing is for. null when the listing does not say. */
  variantId: string | null;
  retailerId: string;
  productUrl: string;
  sellerName: string | null;
  /** Model number as printed on the retailer listing, if the listing shows one. */
  listedModelNumber: string | null;
  listedPrice: number;
  shipping: Shipping;
  discounts: Discount[];
  currency: CurrencyCode;
  availability: Availability;
  condition: Condition;
  warranty: string | null;
  sourceType: SourceType;
  lastCheckedAt: string; // ISO 8601
}

export type DataStatus = "sample" | "live" | "stale" | "unavailable";

export interface Freshness {
  status: Exclude<DataStatus, "unavailable">;
  ageHours: number | null;
}

export interface ComparableTotal {
  /** listed price + known mandatory delivery - confirmed discounts (never below 0). */
  amount: number;
  /** false when a mandatory charge is unknown, so the real total may be higher. */
  isComplete: boolean;
  listedPrice: number;
  shippingAmount: number | null;
  appliedDiscounts: Discount[];
  appliedDiscountTotal: number;
  conditionalDiscounts: Discount[];
  notes: string[];
}

export type MatchLevel = "exact" | "unverified" | "mismatch";
export interface MatchResult {
  level: MatchLevel;
  reason: string;
}

export interface RankedOffer {
  offer: Offer;
  retailer: Retailer | null;
  match: MatchResult;
  total: ComparableTotal;
  freshness: Freshness;
  eligible: boolean;
  exclusionReasons: string[];
  warnings: string[];
  /** 1-based position among eligible offers. null when excluded. */
  rank: number | null;
}

export interface ProductSummary {
  product: Product;
  categoryName: string;
  bestOffer: RankedOffer | null;
}

export interface DataSourceStatus {
  id: string;
  label: string;
  status: DataStatus;
  lastCheckedAt: string | null;
  message: string;
}
