import type { Freshness, Offer } from "./types";

export const DEFAULT_MAX_AGE_HOURS = 24;

/**
 * Sample offers are always "sample", whatever their timestamp says.
 * Other offers are "live" when checked within maxAgeHours, otherwise "stale".
 * Unparseable or future timestamps are treated as stale because they cannot be trusted.
 */
export function assessFreshness(
  offer: Pick<Offer, "sourceType" | "lastCheckedAt">,
  now: Date,
  maxAgeHours: number = DEFAULT_MAX_AGE_HOURS,
): Freshness {
  const checked = new Date(offer.lastCheckedAt).getTime();
  const ageHours = Number.isNaN(checked) ? null : (now.getTime() - checked) / 3_600_000;

  if (offer.sourceType === "sample") return { status: "sample", ageHours };
  if (ageHours === null || ageHours < 0 || ageHours > maxAgeHours) {
    return { status: "stale", ageHours };
  }
  return { status: "live", ageHours };
}
