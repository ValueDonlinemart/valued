import type { MatchResult, Offer, Product } from "./types";

/** "WH-1000XM5" and "wh1000xm5" compare equal. */
export function normalizeModel(value: string): string {
  return value.toUpperCase().replace(/[^A-Z0-9]/g, "");
}

/**
 * Decides whether an offer is for the product (and variant) being compared.
 * Similar names are NOT enough: model number and configuration must agree.
 *
 *  mismatch   - the listing states a different model or a different variant
 *  unverified - the listing does not state enough to confirm (no model, or no variant)
 *  exact      - model confirmed and variant (if one is being compared) confirmed
 */
export function matchOffer(
  product: Pick<Product, "modelNumber" | "variants">,
  offer: Pick<Offer, "listedModelNumber" | "variantId">,
  targetVariantId: string | null,
): MatchResult {
  if (
    offer.listedModelNumber &&
    normalizeModel(offer.listedModelNumber) !== normalizeModel(product.modelNumber)
  ) {
    return {
      level: "mismatch",
      reason: `Listing is for model ${offer.listedModelNumber}, not ${product.modelNumber}.`,
    };
  }

  if (targetVariantId && offer.variantId && offer.variantId !== targetVariantId) {
    const theirs = product.variants.find((v) => v.id === offer.variantId)?.label ?? "another configuration";
    return { level: "mismatch", reason: `Listing is for a different configuration (${theirs}).` };
  }

  if (!offer.listedModelNumber) {
    return { level: "unverified", reason: "The listing does not show a model number." };
  }
  if (targetVariantId && !offer.variantId) {
    return { level: "unverified", reason: "The listing does not say which configuration it is." };
  }
  return { level: "exact", reason: "Model number and configuration match." };
}
