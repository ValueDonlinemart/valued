import { rankOffers } from "./ranking";
import { sampleProvider } from "./providers/sample";
import type { CatalogProvider } from "./providers/types";
import type {
  Category,
  DataSourceStatus,
  Offer,
  Product,
  ProductSummary,
  RankedOffer,
  Retailer,
} from "./types";

/**
 * The single place the app reads catalogue data from.
 * To use another source (e.g. Supabase in a later stage), change `provider` here.
 */
const provider: CatalogProvider = sampleProvider;

export const getCategories = (): Promise<Category[]> => provider.getCategories();
export const getRetailers = (): Promise<Retailer[]> => provider.getRetailers();
export const getDataSourceStatus = (now = new Date()): Promise<DataSourceStatus> => provider.getStatus(now);

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const products = await provider.getProducts();
  return products.find((p) => p.slug === slug) ?? null;
}

export async function getAllProducts(): Promise<Product[]> {
  return provider.getProducts();
}

export async function getOfferById(id: string): Promise<{ offer: Offer; retailer: Retailer } | null> {
  const [offers, retailers] = await Promise.all([provider.getOffers(), provider.getRetailers()]);
  const offer = offers.find((o) => o.id === id);
  if (!offer) return null;
  const retailer = retailers.find((r) => r.id === offer.retailerId);
  return retailer ? { offer, retailer } : null;
}

export function defaultVariantId(product: Product): string | null {
  return product.variants[0]?.id ?? null;
}

export async function getRankedOffers(
  product: Product,
  variantId: string | null,
  now = new Date(),
): Promise<RankedOffer[]> {
  const [offers, retailers] = await Promise.all([provider.getOffers(), provider.getRetailers()]);
  const forProduct = offers.filter((o) => o.productId === product.id);
  return rankOffers(product, forProduct, retailers, { now, targetVariantId: variantId });
}

/** One summary per product, using the default variant's best eligible offer. */
export async function getProductSummaries(now = new Date()): Promise<ProductSummary[]> {
  const [products, categories, offers, retailers] = await Promise.all([
    provider.getProducts(),
    provider.getCategories(),
    provider.getOffers(),
    provider.getRetailers(),
  ]);
  const categoryName = new Map(categories.map((c) => [c.slug, c.name]));
  return products.map((product) => {
    const ranked = rankOffers(
      product,
      offers.filter((o) => o.productId === product.id),
      retailers,
      { now, targetVariantId: defaultVariantId(product) },
    );
    return {
      product,
      categoryName: categoryName.get(product.categorySlug) ?? "Other",
      bestOffer: ranked.find((r) => r.eligible) ?? null,
    };
  });
}

/** Products whose best offer carries a confirmed discount, biggest percentage first. */
export async function getDeals(limit: number, now = new Date()): Promise<ProductSummary[]> {
  const summaries = await getProductSummaries(now);
  const pct = (s: ProductSummary) =>
    s.bestOffer && s.bestOffer.total.listedPrice > 0
      ? s.bestOffer.total.appliedDiscountTotal / s.bestOffer.total.listedPrice
      : 0;
  return summaries
    .filter((s) => s.bestOffer && s.bestOffer.total.appliedDiscountTotal > 0)
    .sort((a, b) => pct(b) - pct(a))
    .slice(0, limit);
}

export async function getSimilarProducts(product: Product, limit: number): Promise<ProductSummary[]> {
  const summaries = await getProductSummaries();
  return summaries
    .filter((s) => s.product.id !== product.id)
    .map((s) => ({
      s,
      score: (s.product.categorySlug === product.categorySlug ? 2 : 0) + (s.product.brand === product.brand ? 1 : 0),
    }))
    .filter((x) => x.score >= 2)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((x) => x.s);
}
