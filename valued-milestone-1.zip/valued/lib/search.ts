import type { ProductSummary } from "./types";

export const SORT_OPTIONS = ["relevance", "price_asc", "price_desc"] as const;
export type SortOption = (typeof SORT_OPTIONS)[number];
export const SORT_LABELS: Record<SortOption, string> = {
  relevance: "Best match",
  price_asc: "Comparable price, low to high",
  price_desc: "Comparable price, high to low",
};

export const PAGE_SIZE = 12;
export const MIN_QUERY_LENGTH = 2;
export const MAX_QUERY_LENGTH = 100;

export interface SearchParams {
  q: string | null;
  category: string | null;
  sort: SortOption;
  page: number;
}

export interface ParsedSearch {
  params: SearchParams;
  /** Problems the visitor should fix (shown as an error). */
  errors: string[];
  /** Harmless adjustments we made (shown as a note). */
  notices: string[];
}

type RawParams = Record<string, string | string[] | undefined>;

const first = (v: string | string[] | undefined): string | undefined => (Array.isArray(v) ? v[0] : v);

/** Turns untrusted URL parameters into safe, validated values. Never throws. */
export function parseSearchParams(raw: RawParams, validCategories: readonly string[]): ParsedSearch {
  const errors: string[] = [];
  const notices: string[] = [];

  // Query: strip control characters, collapse whitespace, then validate length.
  // eslint-disable-next-line no-control-regex
  const cleaned = (first(raw.q) ?? "").replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim();
  let q: string | null = null;
  if (cleaned.length > 0) {
    if (cleaned.length < MIN_QUERY_LENGTH) {
      errors.push(`Enter at least ${MIN_QUERY_LENGTH} characters to search.`);
    } else if (cleaned.length > MAX_QUERY_LENGTH) {
      errors.push(`Searches are limited to ${MAX_QUERY_LENGTH} characters.`);
    } else {
      q = cleaned;
    }
  }

  const rawCategory = first(raw.category)?.trim().toLowerCase();
  let category: string | null = null;
  if (rawCategory) {
    if (validCategories.includes(rawCategory)) category = rawCategory;
    else notices.push("That category does not exist, so all categories are shown.");
  }

  const rawSort = first(raw.sort);
  const sort = (SORT_OPTIONS as readonly string[]).includes(rawSort ?? "") ? (rawSort as SortOption) : "relevance";

  const n = Number.parseInt(first(raw.page) ?? "1", 10);
  const page = Number.isFinite(n) && n >= 1 && n <= 10_000 ? n : 1;

  return { params: { q, category, sort, page }, errors, notices };
}

const words = (text: string): string[] => text.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
const compact = (text: string): string => text.toLowerCase().replace(/[^a-z0-9]/g, "");

/** Scores one product for a query. Returns 0 when any search word has no match. */
function scoreProduct(summary: ProductSummary, tokens: string[]): number {
  const { product, categoryName } = summary;
  const nameWords = words(product.name);
  const brandWords = words(product.brand);
  const keywordWords = product.keywords.flatMap(words);
  const categoryWords = words(categoryName);
  const modelCompact = compact(product.modelNumber);

  let total = 0;
  for (const token of tokens) {
    const t = compact(token);
    if (!t) continue;
    let s = 0;
    if (t.length >= 3 && modelCompact.includes(t)) s = 5;
    else if (nameWords.some((w) => w.startsWith(t))) s = 4;
    else if (brandWords.some((w) => w.startsWith(t))) s = 3;
    else if (keywordWords.some((w) => w.startsWith(t))) s = 2;
    else if (categoryWords.some((w) => w.startsWith(t))) s = 1;
    if (s === 0) return 0; // every word must match: no unrelated products
    total += s;
  }
  return total;
}

export interface SearchResult {
  items: ProductSummary[];
  total: number;
  page: number;
  pageCount: number;
}

export function searchCatalogue(summaries: ProductSummary[], params: SearchParams): SearchResult {
  const tokens = params.q ? words(params.q) : [];

  let scored = summaries
    .filter((s) => !params.category || s.product.categorySlug === params.category)
    .map((s) => ({ s, score: tokens.length ? scoreProduct(s, tokens) : 1 }))
    .filter((x) => x.score > 0);

  const price = (s: ProductSummary) => s.bestOffer?.total.amount ?? null;
  scored = scored.sort((a, b) => {
    if (params.sort === "price_asc" || params.sort === "price_desc") {
      const pa = price(a.s);
      const pb = price(b.s);
      if (pa === null && pb === null) return a.s.product.name.localeCompare(b.s.product.name);
      if (pa === null) return 1; // products without a comparable price go last
      if (pb === null) return -1;
      return params.sort === "price_asc" ? pa - pb : pb - pa;
    }
    return b.score - a.score || a.s.product.name.localeCompare(b.s.product.name);
  });

  const total = scored.length;
  const pageCount = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const page = Math.min(params.page, pageCount);
  const items = scored.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE).map((x) => x.s);
  return { items, total, page, pageCount };
}

/** Builds a URL that keeps the current search state, with some values changed. */
export function buildSearchHref(
  basePath: string,
  params: SearchParams,
  overrides: Partial<SearchParams> = {},
): string {
  const merged = { ...params, ...overrides };
  const usp = new URLSearchParams();
  if (merged.q) usp.set("q", merged.q);
  if (merged.category) usp.set("category", merged.category);
  if (merged.sort !== "relevance") usp.set("sort", merged.sort);
  if (merged.page > 1) usp.set("page", String(merged.page));
  const qs = usp.toString();
  return qs ? `${basePath}?${qs}` : basePath;
}
