export const POPULAR_SEARCHES = ["iPhone 15", "Sony headphones", "MacBook Air", "Galaxy Watch", "Air fryer"] as const;
export const DEMO_NOTICE = "Demo data — prices are illustrative and are not live offers.";
export const VERIFY_NOTICE = "Prices and availability can change. Check the final price and terms on the retailer's website before you buy.";
