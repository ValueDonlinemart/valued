import { formatINR } from "./format";
import { assessFreshness, DEFAULT_MAX_AGE_HOURS } from "./freshness";
import { matchOffer } from "./matching";
import { calculateComparableTotal } from "./pricing";
import type {
  Availability,
  Condition,
  MatchLevel,
  Offer,
  Product,
  RankedOffer,
  Retailer,
} from "./types";

export interface RankOptions {
  now?: Date;
  /** Variant being compared. Pass null for products without variants. */
  targetVariantId?: string | null;
  /** Conditions the buyer accepts. Defaults to new only. */
  allowedConditions?: Condition[];
  maxAgeHours?: number;
}

const MATCH_ORDER: Record<MatchLevel, number> = { exact: 0, unverified: 1, mismatch: 2 };
const CONDITION_ORDER: Record<Condition, number> = { new: 0, open_box: 1, refurbished: 2, used: 3 };
const AVAILABILITY_ORDER: Record<Availability, number> = {
  in_stock: 0,
  low_stock: 1,
  preorder: 2,
  unknown: 3,
  out_of_stock: 4,
};
const CONDITION_LABEL: Record<Condition, string> = {
  new: "new",
  open_box: "open-box",
  refurbished: "refurbished",
  used: "used",
};

const BIG = Number.MAX_SAFE_INTEGER;

/**
 * Ranks offers for one product. Order of priority (each step only breaks ties of the previous):
 *  1. correct product match (exact before unverified)
 *  2. comparable total price
 *  3. verified retailer
 *  4. condition, then warranty
 *  5. availability
 *  6. data freshness
 *
 * Offers that are the wrong model/variant, out of stock, from a paused retailer, or in an
 * unaccepted condition are EXCLUDED from the ranking (rank = null) and listed after the ranked ones.
 * The cheapest offer therefore never wins just by being cheapest.
 */
export function rankOffers(
  product: Product,
  offers: Offer[],
  retailers: Retailer[],
  options: RankOptions = {},
): RankedOffer[] {
  const now = options.now ?? new Date();
  const targetVariantId = options.targetVariantId ?? null;
  const allowed = options.allowedConditions ?? ["new"];
  const maxAge = options.maxAgeHours ?? DEFAULT_MAX_AGE_HOURS;
  const retailerById = new Map(retailers.map((r) => [r.id, r]));

  const entries: RankedOffer[] = offers.map((offer) => {
    const retailer = retailerById.get(offer.retailerId) ?? null;
    const match = matchOffer(product, offer, targetVariantId);
    const total = calculateComparableTotal(offer);
    const freshness = assessFreshness(offer, now, maxAge);

    const exclusionReasons: string[] = [];
    if (!retailer) exclusionReasons.push("Retailer is not recognised.");
    else if (retailer.status !== "active") exclusionReasons.push(`${retailer.name} is currently paused.`);
    if (match.level === "mismatch") exclusionReasons.push(match.reason);
    if (offer.availability === "out_of_stock") exclusionReasons.push("Out of stock.");
    if (!allowed.includes(offer.condition)) {
      exclusionReasons.push(`Item is ${CONDITION_LABEL[offer.condition]}, not in the accepted conditions.`);
    }

    const warnings: string[] = [];
    if (match.level === "unverified") warnings.push(match.reason);
    if (!total.isComplete) warnings.push("Delivery charge unknown, so the total may be higher.");
    if (freshness.status === "stale") warnings.push("Price has not been checked recently.");
    if (freshness.status === "sample") warnings.push("Demo data, not a live offer.");
    if (offer.availability === "low_stock") warnings.push("Low stock.");
    if (offer.availability === "preorder") warnings.push("Pre-order.");
    if (offer.availability === "unknown") warnings.push("Availability unknown.");

    return {
      offer,
      retailer,
      match,
      total,
      freshness,
      eligible: exclusionReasons.length === 0,
      exclusionReasons,
      warnings,
      rank: null,
    };
  });

  const compare = (a: RankedOffer, b: RankedOffer): number =>
    MATCH_ORDER[a.match.level] - MATCH_ORDER[b.match.level] ||
    a.total.amount - b.total.amount ||
    Number(b.retailer?.verified ?? false) - Number(a.retailer?.verified ?? false) ||
    CONDITION_ORDER[a.offer.condition] - CONDITION_ORDER[b.offer.condition] ||
    Number(Boolean(b.offer.warranty)) - Number(Boolean(a.offer.warranty)) ||
    AVAILABILITY_ORDER[a.offer.availability] - AVAILABILITY_ORDER[b.offer.availability] ||
    (a.freshness.ageHours ?? BIG) - (b.freshness.ageHours ?? BIG) ||
    a.offer.id.localeCompare(b.offer.id);

  const eligible = entries.filter((e) => e.eligible).sort(compare);
  eligible.forEach((e, i) => {
    e.rank = i + 1;
  });
  const excluded = entries
    .filter((e) => !e.eligible)
    .sort((a, b) => a.total.amount - b.total.amount || a.offer.id.localeCompare(b.offer.id));

  return [...eligible, ...excluded];
}

/** Plain-language explanation of why the top offer is on top, including cheaper offers that were skipped. */
export function explainRanking(ranked: RankedOffer[]): string {
  const eligible = ranked.filter((r) => r.eligible);
  const best = eligible[0];
  if (!best) {
    return "No offer is currently eligible for comparison. Every recorded listing is excluded, for example because it is out of stock or for a different model.";
  }

  const name = best.retailer?.name ?? "This retailer";
  const price = formatINR(best.total.amount);
  const parts: string[] = [];

  if (best.match.level === "exact") {
    parts.push(
      eligible.length === 1
        ? `${name} is the only eligible offer, at a comparable total of ${price}.`
        : `${name} has the lowest comparable total (${price}) among in-stock offers that match this exact model and configuration.`,
    );
  } else {
    parts.push(
      `No listing confirms the exact model, so ${name} is shown as the lowest-priced unverified offer (${price}).`,
    );
  }

  if (!best.total.isComplete) {
    parts.push("Its delivery charge is unknown, so the real total may be higher.");
  }

  const cheaperExcluded = ranked.filter((r) => !r.eligible && r.total.amount < best.total.amount);
  if (cheaperExcluded.length > 0) {
    const detail = cheaperExcluded
      .map((r) => `${r.retailer?.name ?? "Unknown retailer"} (${r.exclusionReasons[0] ?? "excluded"})`)
      .join("; ");
    parts.push(
      `${cheaperExcluded.length} lower-priced ${cheaperExcluded.length === 1 ? "listing was" : "listings were"} not ranked: ${detail}`,
    );
  }

  return parts.join(" ");
}
