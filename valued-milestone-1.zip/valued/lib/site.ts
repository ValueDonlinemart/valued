export const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000").replace(/\/$/, "");
/** Stays false while the site shows demo data, so illustrative prices are not indexed. */
export const allowIndexing = process.env.NEXT_PUBLIC_ALLOW_INDEXING === "true";
