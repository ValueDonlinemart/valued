import type { Category, Discount, Offer, Product, Retailer } from "../types";

/**
 * DEMONSTRATION DATA ONLY.
 *
 * - Retailers are fictional. All links point to example.com (a domain reserved for documentation).
 * - Prices, stock, discounts and timestamps are invented to exercise the comparison engine.
 * - Product specifications are short summaries for demonstration. Verify with the manufacturer.
 * - Model numbers are illustrative.
 */

/** The date the demo snapshot was written. Sample offers are never treated as live. */
export const SAMPLE_SNAPSHOT_AT = "2026-10-01T04:30:00.000Z";

export const sampleCategories: Category[] = [
  { id: "smartphones", slug: "smartphones", name: "Smartphones", description: "Phones from major brands." },
  { id: "laptops", slug: "laptops", name: "Laptops", description: "Laptops for work, study and play." },
  { id: "headphones", slug: "headphones", name: "Headphones", description: "Over-ear headphones and earbuds." },
  { id: "smartwatches", slug: "smartwatches", name: "Smartwatches", description: "Wearables and fitness watches." },
  { id: "home-appliances", slug: "home-appliances", name: "Home Appliances", description: "Appliances for the kitchen and home." },
  { id: "tvs-entertainment", slug: "tvs-entertainment", name: "TVs and Entertainment", description: "Televisions and home entertainment." },
];

export const sampleRetailers: Retailer[] = [
  { id: "demomart", name: "DemoMart", baseUrl: "https://example.com", integrationType: "sample", status: "active", verified: true },
  { id: "sampleshop", name: "SampleShop", baseUrl: "https://example.com", integrationType: "sample", status: "active", verified: true },
  { id: "example-electronics", name: "Example Electronics", baseUrl: "https://example.com", integrationType: "sample", status: "active", verified: true },
  { id: "test-bazaar", name: "Test Bazaar", baseUrl: "https://example.com", integrationType: "sample", status: "active", verified: false },
];

export const sampleProducts: Product[] = [
  {
    id: "iphone-15", slug: "iphone-15", name: "Apple iPhone 15", brand: "Apple", modelNumber: "A3092",
    categorySlug: "smartphones", imageUrl: null,
    description: "Apple's 2023 mainstream iPhone with a USB-C port and a 48 MP main camera.",
    specifications: { Display: "6.1-inch Super Retina XDR OLED", Chip: "A16 Bionic", "Rear camera": "48 MP main and 12 MP ultra wide", Connector: "USB-C", "Water resistance": "IP68" },
    keywords: ["phone", "mobile", "ios", "iphone"],
    variants: [
      { id: "iphone-15-128", label: "128 GB", attributes: { Storage: "128 GB" } },
      { id: "iphone-15-256", label: "256 GB", attributes: { Storage: "256 GB" } },
    ],
  },
  {
    id: "galaxy-s24", slug: "samsung-galaxy-s24", name: "Samsung Galaxy S24", brand: "Samsung", modelNumber: "SM-S921B",
    categorySlug: "smartphones", imageUrl: null,
    description: "Samsung's compact 2024 flagship with a 120 Hz display and a triple rear camera.",
    specifications: { Display: "6.2-inch Dynamic AMOLED 2X, 120 Hz", "Rear camera": "50 MP main, 12 MP ultra wide, 10 MP telephoto", Battery: "4,000 mAh" },
    keywords: ["phone", "mobile", "android", "galaxy"],
    variants: [
      { id: "galaxy-s24-256", label: "8 GB RAM, 256 GB", attributes: { RAM: "8 GB", Storage: "256 GB" } },
      { id: "galaxy-s24-512", label: "8 GB RAM, 512 GB", attributes: { RAM: "8 GB", Storage: "512 GB" } },
    ],
  },
  {
    id: "macbook-air-m2", slug: "apple-macbook-air-13-m2", name: "Apple MacBook Air 13-inch (M2)", brand: "Apple", modelNumber: "A2681",
    categorySlug: "laptops", imageUrl: null,
    description: "Thin and light 13-inch laptop with Apple's M2 chip.",
    specifications: { Display: "13.6-inch Liquid Retina", Chip: "Apple M2", Weight: "1.24 kg", Ports: "MagSafe 3, two Thunderbolt, headphone jack" },
    keywords: ["laptop", "notebook", "macbook", "mac"],
    variants: [
      { id: "mba-m2-256", label: "8 GB RAM, 256 GB SSD", attributes: { RAM: "8 GB", Storage: "256 GB" } },
      { id: "mba-m2-512", label: "8 GB RAM, 512 GB SSD", attributes: { RAM: "8 GB", Storage: "512 GB" } },
    ],
  },
  {
    id: "sony-wh-1000xm5", slug: "sony-wh-1000xm5", name: "Sony WH-1000XM5", brand: "Sony", modelNumber: "WH-1000XM5",
    categorySlug: "headphones", imageUrl: null,
    description: "Wireless over-ear headphones with active noise cancelling.",
    specifications: { Type: "Over-ear, wireless", "Noise cancelling": "Active", "Battery life": "Up to 30 hours with noise cancelling on", Weight: "About 250 g" },
    keywords: ["headphone", "headphones", "wireless", "noise cancelling", "over-ear"],
    variants: [],
  },
  {
    id: "sony-wf-1000xm5", slug: "sony-wf-1000xm5", name: "Sony WF-1000XM5", brand: "Sony", modelNumber: "WF-1000XM5",
    categorySlug: "headphones", imageUrl: null,
    description: "True wireless earbuds with active noise cancelling.",
    specifications: { Type: "In-ear, true wireless", "Noise cancelling": "Active", "Battery life": "About 8 hours per charge with noise cancelling on" },
    keywords: ["earbuds", "headphone", "headphones", "wireless", "noise cancelling", "in-ear"],
    variants: [],
  },
  {
    id: "galaxy-watch6", slug: "samsung-galaxy-watch6-44mm", name: "Samsung Galaxy Watch6 44 mm", brand: "Samsung", modelNumber: "SM-R940",
    categorySlug: "smartwatches", imageUrl: null,
    description: "Samsung's 2023 smartwatch, 44 mm Bluetooth model.",
    specifications: { Display: "1.5-inch Super AMOLED", Size: "44 mm", Connectivity: "Bluetooth" },
    keywords: ["watch", "smartwatch", "wearable", "fitness", "galaxy"],
    variants: [],
  },
  {
    id: "lg-c3-oled-55", slug: "lg-c3-oled-55", name: "LG C3 55-inch OLED TV", brand: "LG", modelNumber: "OLED55C3PSA",
    categorySlug: "tvs-entertainment", imageUrl: null,
    description: "55-inch 4K OLED television running webOS.",
    specifications: { Screen: "55-inch OLED evo, 4K", "Refresh rate": "120 Hz", "Smart platform": "webOS" },
    keywords: ["tv", "television", "oled", "4k", "smart tv"],
    variants: [],
  },
  {
    id: "philips-air-fryer-hd9252", slug: "philips-air-fryer-hd9252", name: "Philips Air Fryer HD9252", brand: "Philips", modelNumber: "HD9252/90",
    categorySlug: "home-appliances", imageUrl: null,
    description: "Countertop air fryer for cooking with little oil.",
    specifications: { Type: "Air fryer", Technology: "Rapid Air" },
    keywords: ["air fryer", "airfryer", "kitchen", "cooking", "appliance"],
    variants: [],
  },
];

const modelOf = (productId: string) => sampleProducts.find((p) => p.id === productId)?.modelNumber ?? null;

interface Seed {
  id: string;
  product: string;
  retailer: string;
  price: number;
  variant?: string;
  shipping?: Offer["shipping"];
  discounts?: Discount[];
  availability?: Offer["availability"];
  condition?: Offer["condition"];
  warranty?: string | null;
  /** Override the model printed on the listing. null means the listing shows no model. */
  listedModel?: string | null;
}

const instant = (id: string, amount: number): Discount => ({
  id, label: "Instant discount applied at checkout", kind: "instant", amount, eligibility: "confirmed",
});
const bank = (id: string, amount: number): Discount => ({
  id, label: "Bank card offer", kind: "bank", amount, eligibility: "conditional",
  condition: "Only with an eligible credit or debit card",
});
const exchange = (id: string, amount: number): Discount => ({
  id, label: "Exchange bonus", kind: "exchange", amount, eligibility: "conditional",
  condition: "Only when you trade in an eligible old device",
});

function toOffer(s: Seed): Offer {
  const slug = sampleProducts.find((p) => p.id === s.product)?.slug ?? s.product;
  return {
    id: s.id,
    productId: s.product,
    variantId: s.variant ?? null,
    retailerId: s.retailer,
    productUrl: `https://example.com/demo/${s.retailer}/${slug}`,
    sellerName: null,
    listedModelNumber: s.listedModel === undefined ? modelOf(s.product) : s.listedModel,
    listedPrice: s.price,
    shipping: s.shipping ?? { status: "free" },
    discounts: s.discounts ?? [],
    currency: "INR",
    availability: s.availability ?? "in_stock",
    condition: s.condition ?? "new",
    warranty: s.warranty === undefined ? "Manufacturer warranty" : s.warranty,
    sourceType: "sample",
    lastCheckedAt: SAMPLE_SNAPSHOT_AT,
  };
}

// Several offers below are deliberately awkward (wrong model, out of stock, unknown delivery,
// conditional discounts) so the comparison engine has realistic edge cases to handle.
const seeds: Seed[] = [
  // iPhone 15
  { id: "o-101", product: "iphone-15", variant: "iphone-15-128", retailer: "demomart", price: 65900, discounts: [instant("d-101a", 1000), bank("d-101b", 3000)] },
  { id: "o-102", product: "iphone-15", variant: "iphone-15-128", retailer: "sampleshop", price: 64990, shipping: { status: "paid", amount: 99 } },
  { id: "o-103", product: "iphone-15", variant: "iphone-15-128", retailer: "example-electronics", price: 62990, availability: "out_of_stock" },
  { id: "o-104", product: "iphone-15", variant: "iphone-15-128", retailer: "test-bazaar", price: 58990, listedModel: "A2882" },
  { id: "o-105", product: "iphone-15", variant: "iphone-15-128", retailer: "demomart", price: 54500, condition: "refurbished", warranty: "6 months seller warranty" },
  { id: "o-106", product: "iphone-15", variant: "iphone-15-256", retailer: "test-bazaar", price: 71999 },
  { id: "o-107", product: "iphone-15", variant: "iphone-15-256", retailer: "sampleshop", price: 72490, shipping: { status: "unknown" } },
  { id: "o-108", product: "iphone-15", variant: "iphone-15-256", retailer: "demomart", price: 73900, discounts: [exchange("d-108a", 8000)] },
  // Galaxy S24
  { id: "o-201", product: "galaxy-s24", variant: "galaxy-s24-256", retailer: "sampleshop", price: 74999, discounts: [instant("d-201a", 2000)] },
  { id: "o-202", product: "galaxy-s24", variant: "galaxy-s24-256", retailer: "example-electronics", price: 72500, shipping: { status: "paid", amount: 150 }, availability: "low_stock" },
  { id: "o-203", product: "galaxy-s24", variant: "galaxy-s24-256", retailer: "demomart", price: 76999, discounts: [bank("d-203a", 5000)] },
  { id: "o-204", product: "galaxy-s24", variant: "galaxy-s24-512", retailer: "test-bazaar", price: 84999 },
  // MacBook Air M2
  { id: "o-301", product: "macbook-air-m2", variant: "mba-m2-256", retailer: "demomart", price: 99900, discounts: [bank("d-301a", 7500)] },
  { id: "o-302", product: "macbook-air-m2", variant: "mba-m2-256", retailer: "example-electronics", price: 97990 },
  { id: "o-303", product: "macbook-air-m2", variant: "mba-m2-256", retailer: "sampleshop", price: 98490 },
  { id: "o-304", product: "macbook-air-m2", variant: "mba-m2-512", retailer: "demomart", price: 119900 },
  // Sony WH-1000XM5
  { id: "o-401", product: "sony-wh-1000xm5", retailer: "sampleshop", price: 29990 },
  { id: "o-402", product: "sony-wh-1000xm5", retailer: "demomart", price: 27990, shipping: { status: "paid", amount: 99 }, discounts: [bank("d-402a", 1500)] },
  { id: "o-403", product: "sony-wh-1000xm5", retailer: "test-bazaar", price: 26490, shipping: { status: "unknown" } },
  // Sony WF-1000XM5
  { id: "o-501", product: "sony-wf-1000xm5", retailer: "demomart", price: 24990 },
  { id: "o-502", product: "sony-wf-1000xm5", retailer: "example-electronics", price: 23990, shipping: { status: "paid", amount: 149 }, discounts: [instant("d-502a", 500)] },
  // Galaxy Watch6
  { id: "o-601", product: "galaxy-watch6", retailer: "sampleshop", price: 29999 },
  { id: "o-602", product: "galaxy-watch6", retailer: "demomart", price: 27999, discounts: [instant("d-602a", 1000)] },
  // LG C3
  { id: "o-701", product: "lg-c3-oled-55", retailer: "example-electronics", price: 119990 },
  { id: "o-702", product: "lg-c3-oled-55", retailer: "sampleshop", price: 114990, shipping: { status: "paid", amount: 1500 } },
  { id: "o-703", product: "lg-c3-oled-55", retailer: "demomart", price: 117990, discounts: [bank("d-703a", 10000)] },
  // Philips air fryer
  { id: "o-801", product: "philips-air-fryer-hd9252", retailer: "demomart", price: 7499 },
  { id: "o-802", product: "philips-air-fryer-hd9252", retailer: "test-bazaar", price: 6999, shipping: { status: "paid", amount: 199 } },
  { id: "o-803", product: "philips-air-fryer-hd9252", retailer: "sampleshop", price: 7299, discounts: [instant("d-803a", 300)] },
];

export const sampleOffers: Offer[] = seeds.map(toOffer);
