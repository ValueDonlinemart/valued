import type { Config } from "tailwindcss";

// Design tokens for ValueD. Change colours here and every component follows.
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#ecfdf5",
          100: "#d1fae5",
          200: "#a7f3d0",
          500: "#10b981",
          600: "#059669",
          700: "#047857", // primary action colour: 5.5:1 contrast with white text
          800: "#065f46",
        },
        forest: { DEFAULT: "#0b3d2e", 700: "#145a45", 800: "#0f4a38" },
        mint: { DEFAULT: "#f2fbf6", 100: "#e3f5ec" },
        ink: { DEFAULT: "#1c2321", soft: "#3a4541" },
        muted: "#55615c",
        line: "#e1e7e4",
      },
      fontFamily: {
        sans: ["var(--font-sans)", "ui-sans-serif", "system-ui", "sans-serif"],
        display: ["var(--font-display)", "var(--font-sans)", "ui-sans-serif", "sans-serif"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(11, 61, 46, 0.06), 0 4px 12px rgba(11, 61, 46, 0.05)",
      },
    },
  },
  plugins: [],
};
export default config;
