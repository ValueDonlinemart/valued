import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { calculateComparableTotal } from "../lib/pricing";
import type { Discount } from "../lib/types";

const confirmed = (amount: number, id = "c"): Discount => ({ id, label: "Instant", kind: "instant", amount, eligibility: "confirmed" });
const conditional = (amount: number, id = "x"): Discount => ({ id, label: "Bank offer", kind: "bank", amount, eligibility: "conditional", condition: "Eligible card" });

describe("calculateComparableTotal", () => {
  it("adds paid delivery and subtracts confirmed discounts", () => {
    const t = calculateComparableTotal({ listedPrice: 10000, shipping: { status: "paid", amount: 200 }, discounts: [confirmed(500)] });
    assert.equal(t.amount, 9700);
    assert.equal(t.isComplete, true);
  });

  it("treats free delivery as a known zero", () => {
    const t = calculateComparableTotal({ listedPrice: 5000, shipping: { status: "free" }, discounts: [] });
    assert.equal(t.amount, 5000);
    assert.equal(t.shippingAmount, 0);
    assert.equal(t.isComplete, true);
  });

  it("does not apply conditional discounts, and reports them separately", () => {
    const t = calculateComparableTotal({ listedPrice: 10000, shipping: { status: "free" }, discounts: [confirmed(500), conditional(3000)] });
    assert.equal(t.amount, 9500);
    assert.equal(t.appliedDiscounts.length, 1);
    assert.equal(t.conditionalDiscounts.length, 1);
    assert.equal(t.conditionalDiscounts[0]?.amount, 3000);
  });

  it("flags unknown delivery as incomplete instead of assuming zero", () => {
    const t = calculateComparableTotal({ listedPrice: 10000, shipping: { status: "unknown" }, discounts: [] });
    assert.equal(t.isComplete, false);
    assert.equal(t.shippingAmount, null);
    assert.ok(t.notes.some((n) => n.includes("unknown")));
  });

  it("treats an invalid paid amount as unknown", () => {
    const t = calculateComparableTotal({ listedPrice: 100, shipping: { status: "paid", amount: Number.NaN }, discounts: [] });
    assert.equal(t.isComplete, false);
  });

  it("never returns a negative total", () => {
    const t = calculateComparableTotal({ listedPrice: 100, shipping: { status: "free" }, discounts: [confirmed(500)] });
    assert.equal(t.amount, 0);
  });

  it("ignores discounts with invalid amounts and says so", () => {
    const t = calculateComparableTotal({ listedPrice: 1000, shipping: { status: "free" }, discounts: [confirmed(-50), confirmed(Number.NaN, "n")] });
    assert.equal(t.amount, 1000);
    assert.equal(t.notes.length, 2);
  });

  it("avoids floating-point drift", () => {
    const t = calculateComparableTotal({ listedPrice: 0.1, shipping: { status: "paid", amount: 0.2 }, discounts: [] });
    assert.equal(t.amount, 0.3);
  });

  it("rejects an invalid listed price", () => {
    assert.throws(() => calculateComparableTotal({ listedPrice: -1, shipping: { status: "free" }, discounts: [] }), RangeError);
    assert.throws(() => calculateComparableTotal({ listedPrice: Number.NaN, shipping: { status: "free" }, discounts: [] }), RangeError);
  });
});
