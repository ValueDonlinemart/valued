import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { assessFreshness } from "../lib/freshness";
import { matchOffer, normalizeModel } from "../lib/matching";
import { explainRanking, rankOffers } from "../lib/ranking";
import { sampleOffers, sampleProducts, sampleRetailers } from "../lib/data/sample";
import type { Offer, Product } from "../lib/types";

const NOW = new Date("2026-10-11T00:00:00Z");
const iphone = sampleProducts.find((p) => p.id === "iphone-15") as Product;
const offersFor = (id: string) => sampleOffers.filter((o) => o.productId === id);

const base = (over: Partial<Offer>): Offer => ({
  id: "t1", productId: "iphone-15", variantId: "iphone-15-128", retailerId: "demomart", productUrl: "https://example.com/x",
  sellerName: null, listedModelNumber: "A3092", listedPrice: 1000, shipping: { status: "free" }, discounts: [],
  currency: "INR", availability: "in_stock", condition: "new", warranty: "1 year", sourceType: "live",
  lastCheckedAt: "2026-10-10T20:00:00Z", ...over,
});

describe("matching", () => {
  it("normalises model numbers", () => {
    assert.equal(normalizeModel("wh-1000xm5"), normalizeModel("WH 1000XM5"));
  });
  it("flags a different model as a mismatch", () => {
    assert.equal(matchOffer(iphone, { listedModelNumber: "A2882", variantId: "iphone-15-128" }, "iphone-15-128").level, "mismatch");
  });
  it("flags a different variant as a mismatch", () => {
    assert.equal(matchOffer(iphone, { listedModelNumber: "A3092", variantId: "iphone-15-256" }, "iphone-15-128").level, "mismatch");
  });
  it("marks a listing without a model as unverified", () => {
    assert.equal(matchOffer(iphone, { listedModelNumber: null, variantId: "iphone-15-128" }, "iphone-15-128").level, "unverified");
  });
  it("marks a listing without a variant as unverified when comparing a variant", () => {
    assert.equal(matchOffer(iphone, { listedModelNumber: "A3092", variantId: null }, "iphone-15-128").level, "unverified");
  });
  it("accepts an exact match", () => {
    assert.equal(matchOffer(iphone, { listedModelNumber: "a3092", variantId: "iphone-15-128" }, "iphone-15-128").level, "exact");
  });
});

describe("freshness", () => {
  it("never calls sample data live", () => {
    assert.equal(assessFreshness({ sourceType: "sample", lastCheckedAt: NOW.toISOString() }, NOW).status, "sample");
  });
  it("marks recent live data as live and old data as stale", () => {
    assert.equal(assessFreshness({ sourceType: "live", lastCheckedAt: "2026-10-10T20:00:00Z" }, NOW).status, "live");
    assert.equal(assessFreshness({ sourceType: "live", lastCheckedAt: "2026-10-01T00:00:00Z" }, NOW).status, "stale");
  });
  it("treats invalid or future timestamps as stale", () => {
    assert.equal(assessFreshness({ sourceType: "live", lastCheckedAt: "not a date" }, NOW).status, "stale");
    assert.equal(assessFreshness({ sourceType: "live", lastCheckedAt: "2027-01-01T00:00:00Z" }, NOW).status, "stale");
  });
});

describe("rankOffers", () => {
  it("does not let the cheapest wrong-model, out-of-stock or refurbished offers win", () => {
    const ranked = rankOffers(iphone, offersFor("iphone-15"), sampleRetailers, { now: NOW, targetVariantId: "iphone-15-128" });
    const top = ranked[0];
    assert.equal(top?.offer.id, "o-101"); // 65,900 - 1,000 confirmed = 64,900, beats 64,989+99 elsewhere
    assert.equal(top?.rank, 1);
    const excludedIds = ranked.filter((r) => !r.eligible).map((r) => r.offer.id).sort();
    assert.ok(["o-103", "o-104", "o-105", "o-106", "o-107", "o-108"].every((id) => excludedIds.includes(id)));
    assert.ok(ranked.filter((r) => !r.eligible).every((r) => r.rank === null));
  });

  it("excludes other variants when a variant is selected", () => {
    const ranked = rankOffers(iphone, offersFor("iphone-15"), sampleRetailers, { now: NOW, targetVariantId: "iphone-15-256" });
    const eligibleIds = ranked.filter((r) => r.eligible).map((r) => r.offer.id);
    assert.deepEqual(eligibleIds.sort(), ["o-106", "o-107", "o-108"].sort());
  });

  it("does not apply the conditional bank discount when ranking", () => {
    const ranked = rankOffers(iphone, offersFor("iphone-15"), sampleRetailers, { now: NOW, targetVariantId: "iphone-15-128" });
    assert.equal(ranked[0]?.total.amount, 64900);
    assert.equal(ranked[0]?.total.conditionalDiscounts.length, 1);
  });

  it("ranks exact matches before cheaper unverified ones", () => {
    const ranked = rankOffers(iphone, [
      base({ id: "exact", listedPrice: 2000 }),
      base({ id: "unverified", listedPrice: 1000, listedModelNumber: null }),
    ], sampleRetailers, { now: NOW, targetVariantId: "iphone-15-128" });
    assert.deepEqual(ranked.map((r) => r.offer.id), ["exact", "unverified"]);
    assert.ok(ranked[1]?.warnings.length);
  });

  it("breaks price ties by verified retailer, then condition, then warranty", () => {
    const r = rankOffers(iphone, [
      base({ id: "b-unverified-retailer", retailerId: "test-bazaar" }),
      base({ id: "a-verified", retailerId: "demomart" }),
    ], sampleRetailers, { now: NOW, targetVariantId: "iphone-15-128" });
    assert.equal(r[0]?.offer.id, "a-verified");

    const c = rankOffers(iphone, [
      base({ id: "refurb", condition: "refurbished" }),
      base({ id: "openbox", condition: "open_box" }),
    ], sampleRetailers, { now: NOW, targetVariantId: "iphone-15-128", allowedConditions: ["new", "open_box", "refurbished"] });
    assert.equal(c[0]?.offer.id, "openbox");

    const w = rankOffers(iphone, [
      base({ id: "no-warranty", warranty: null }),
      base({ id: "warranty" }),
    ], sampleRetailers, { now: NOW, targetVariantId: "iphone-15-128" });
    assert.equal(w[0]?.offer.id, "warranty");
  });

  it("keeps an offer with unknown delivery but marks the total incomplete", () => {
    const wh = sampleProducts.find((p) => p.id === "sony-wh-1000xm5") as Product;
    const ranked = rankOffers(wh, offersFor("sony-wh-1000xm5"), sampleRetailers, { now: NOW });
    assert.equal(ranked[0]?.offer.id, "o-403");
    assert.equal(ranked[0]?.total.isComplete, false);
    assert.ok(explainRanking(ranked).includes("unknown"));
  });

  it("excludes offers from paused or unknown retailers", () => {
    const paused = sampleRetailers.map((r) => (r.id === "demomart" ? { ...r, status: "paused" as const } : r));
    const ranked = rankOffers(iphone, [base({ id: "p" }), base({ id: "u", retailerId: "nope" })], paused, { now: NOW, targetVariantId: "iphone-15-128" });
    assert.ok(ranked.every((r) => !r.eligible));
  });

  it("is deterministic regardless of input order", () => {
    const offers = offersFor("iphone-15");
    const a = rankOffers(iphone, offers, sampleRetailers, { now: NOW, targetVariantId: "iphone-15-128" }).map((r) => r.offer.id);
    const b = rankOffers(iphone, [...offers].reverse(), sampleRetailers, { now: NOW, targetVariantId: "iphone-15-128" }).map((r) => r.offer.id);
    assert.deepEqual(a, b);
  });

  it("explains skipped cheaper listings", () => {
    const ranked = rankOffers(iphone, offersFor("iphone-15"), sampleRetailers, { now: NOW, targetVariantId: "iphone-15-128" });
    const text = explainRanking(ranked);
    assert.ok(text.includes("DemoMart"));
    assert.ok(text.includes("not ranked"));
    assert.ok(text.includes("Out of stock"));
  });

  it("says plainly when nothing is eligible", () => {
    const ranked = rankOffers(iphone, [base({ availability: "out_of_stock" })], sampleRetailers, { now: NOW, targetVariantId: "iphone-15-128" });
    assert.ok(explainRanking(ranked).startsWith("No offer is currently eligible"));
  });

  it("flags sample offers as demo data and stale live offers as stale", () => {
    const sample = rankOffers(iphone, [base({ sourceType: "sample" })], sampleRetailers, { now: NOW, targetVariantId: "iphone-15-128" });
    assert.ok(sample[0]?.warnings.some((w) => w.includes("Demo data")));
    const stale = rankOffers(iphone, [base({ lastCheckedAt: "2026-09-01T00:00:00Z" })], sampleRetailers, { now: NOW, targetVariantId: "iphone-15-128" });
    assert.equal(stale[0]?.freshness.status, "stale");
  });
});
