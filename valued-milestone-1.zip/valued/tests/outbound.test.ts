import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { getSafeOutboundUrl } from "../lib/outbound";
import { sampleOffers, sampleProducts, sampleRetailers, sampleCategories } from "../lib/data/sample";

const ALLOWED = ["https://example.com"];

describe("getSafeOutboundUrl", () => {
  it("allows https URLs on an allowed host and its subdomains", () => {
    assert.equal(getSafeOutboundUrl("https://example.com/a?b=1", ALLOWED), "https://example.com/a?b=1");
    assert.ok(getSafeOutboundUrl("https://shop.example.com/a", ALLOWED));
  });
  it("rejects other schemes", () => {
    for (const u of ["http://example.com/a", "javascript:alert(1)", "data:text/html,hi", "ftp://example.com"]) {
      assert.equal(getSafeOutboundUrl(u, ALLOWED), null, u);
    }
  });
  it("rejects lookalike and unlisted hosts", () => {
    for (const u of ["https://evilexample.com/", "https://example.com.evil.net/", "https://evil.net/?u=example.com", "https://notexample.com"]) {
      assert.equal(getSafeOutboundUrl(u, ALLOWED), null, u);
    }
  });
  it("rejects embedded credentials and unusual ports", () => {
    assert.equal(getSafeOutboundUrl("https://example.com@evil.net/", ALLOWED), null);
    assert.equal(getSafeOutboundUrl("https://user:pw@example.com/", ALLOWED), null);
    assert.equal(getSafeOutboundUrl("https://example.com:8443/", ALLOWED), null);
  });
  it("rejects relative, protocol-relative and malformed input", () => {
    for (const u of ["/relative", "//evil.net", "", "not a url"]) assert.equal(getSafeOutboundUrl(u, ALLOWED), null, u);
  });
  it("allows nothing when the allow-list is empty or malformed", () => {
    assert.equal(getSafeOutboundUrl("https://example.com", []), null);
    assert.equal(getSafeOutboundUrl("https://example.com", ["garbage"]), null);
  });
});

describe("sample data integrity", () => {
  it("has unique ids and slugs", () => {
    assert.equal(new Set(sampleOffers.map((o) => o.id)).size, sampleOffers.length);
    assert.equal(new Set(sampleProducts.map((p) => p.slug)).size, sampleProducts.length);
  });
  it("only references products, retailers, variants and categories that exist", () => {
    for (const o of sampleOffers) {
      const p = sampleProducts.find((x) => x.id === o.productId);
      assert.ok(p, `${o.id}: product`);
      assert.ok(sampleRetailers.some((r) => r.id === o.retailerId), `${o.id}: retailer`);
      if (o.variantId) assert.ok(p?.variants.some((v) => v.id === o.variantId), `${o.id}: variant`);
    }
    for (const p of sampleProducts) assert.ok(sampleCategories.some((c) => c.slug === p.categorySlug), p.id);
  });
  it("marks every offer as sample data with a safe outbound URL", () => {
    for (const o of sampleOffers) {
      assert.equal(o.sourceType, "sample");
      const r = sampleRetailers.find((x) => x.id === o.retailerId);
      assert.ok(getSafeOutboundUrl(o.productUrl, [r?.baseUrl ?? ""]), o.id);
    }
  });
});
