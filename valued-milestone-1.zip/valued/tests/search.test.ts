import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { getProductSummaries, getCategories } from "../lib/catalog";
import { POPULAR_SEARCHES } from "../lib/constants";
import { buildSearchHref, parseSearchParams, searchCatalogue, PAGE_SIZE, type SearchParams } from "../lib/search";

const CATS = ["smartphones", "laptops", "headphones"];
const params = (over: Partial<SearchParams>): SearchParams => ({ q: null, category: null, sort: "relevance", page: 1, ...over });
const names = async (over: Partial<SearchParams>) => searchCatalogue(await getProductSummaries(), params(over)).items.map((s) => s.product.name);

describe("parseSearchParams", () => {
  it("trims and collapses whitespace", () => {
    assert.equal(parseSearchParams({ q: "  iphone   15 " }, CATS).params.q, "iphone 15");
  });
  it("treats empty input as no query without an error", () => {
    const p = parseSearchParams({ q: "   " }, CATS);
    assert.equal(p.params.q, null);
    assert.equal(p.errors.length, 0);
  });
  it("rejects one-character and over-long queries", () => {
    assert.equal(parseSearchParams({ q: "a" }, CATS).errors.length, 1);
    assert.equal(parseSearchParams({ q: "x".repeat(101) }, CATS).errors.length, 1);
  });
  it("uses the first value when a parameter is repeated", () => {
    assert.equal(parseSearchParams({ q: ["sony", "apple"] }, CATS).params.q, "sony");
  });
  it("strips control characters", () => {
    assert.equal(parseSearchParams({ q: "so\u0000ny\n" }, CATS).params.q, "so ny");
  });
  it("falls back safely on invalid category, sort and page", () => {
    const p = parseSearchParams({ category: "<script>", sort: "hack", page: "-4" }, CATS);
    assert.equal(p.params.category, null);
    assert.equal(p.params.sort, "relevance");
    assert.equal(p.params.page, 1);
    assert.equal(p.notices.length, 1);
    assert.equal(parseSearchParams({ page: "abc" }, CATS).params.page, 1);
  });
  it("accepts a valid category", () => {
    assert.equal(parseSearchParams({ category: "LAPTOPS" }, CATS).params.category, "laptops");
  });
});

describe("searchCatalogue", () => {
  it("finds by name, brand, model number and keyword", async () => {
    assert.deepEqual(await names({ q: "iphone" }), ["Apple iPhone 15"]);
    assert.ok((await names({ q: "samsung" })).length >= 2);
    assert.deepEqual(await names({ q: "SM-S921B" }), ["Samsung Galaxy S24"]);
    assert.deepEqual(await names({ q: "a3092" }), ["Apple iPhone 15"]);
    assert.ok((await names({ q: "wh1000xm5" })).includes("Sony WH-1000XM5"));
    assert.ok((await names({ q: "phone" })).includes("Apple iPhone 15"));
  });
  it("requires every word to match, so unrelated products are not shown", async () => {
    assert.deepEqual(await names({ q: "iphone sony" }), []);
    assert.deepEqual(await names({ q: "zzzzzz" }), []);
  });
  it("filters by category and combines with a query", async () => {
    const phones = await names({ category: "smartphones" });
    assert.equal(phones.length, 2);
    assert.deepEqual(await names({ q: "apple", category: "laptops" }), ["Apple MacBook Air 13-inch (M2)"]);
  });
  it("sorts by comparable price with unpriced products last", async () => {
    const result = searchCatalogue(await getProductSummaries(), params({ sort: "price_asc" }));
    const prices = result.items.map((s) => s.bestOffer?.total.amount ?? Infinity);
    assert.deepEqual(prices, [...prices].sort((a, b) => a - b));
  });
  it("paginates and clamps out-of-range pages", async () => {
    const r = searchCatalogue(await getProductSummaries(), params({ page: 999 }));
    assert.equal(r.page, r.pageCount);
    assert.ok(r.items.length <= PAGE_SIZE);
  });
  it("every popular search on the homepage returns results", async () => {
    for (const q of POPULAR_SEARCHES) {
      assert.ok((await names({ q })).length > 0, `no results for "${q}"`);
    }
  });
  it("lists every category in the catalogue", async () => {
    assert.ok((await getCategories()).length >= 6);
  });
});

describe("buildSearchHref", () => {
  it("keeps state and omits defaults", () => {
    assert.equal(buildSearchHref("/search", params({ q: "iphone" })), "/search?q=iphone");
    assert.equal(buildSearchHref("/products", params({ category: "laptops", sort: "price_asc" }), { page: 2 }), "/products?category=laptops&sort=price_asc&page=2");
    assert.equal(buildSearchHref("/products", params({})), "/products");
  });
});
