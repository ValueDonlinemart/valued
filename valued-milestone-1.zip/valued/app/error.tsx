"use client";

import { buttonClasses } from "@/components/ui/button";

// Shows a generic message only: error details can contain internal information.
export default function Error({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div role="alert" className="mx-auto max-w-3xl px-4 py-20 sm:px-6">
      <h1 className="text-3xl font-bold">Something went wrong</h1>
      <p className="mt-3 text-ink-soft">We could not load this page. Try again, and if the problem continues, come back in a few minutes.</p>
      <button type="button" onClick={reset} className={buttonClasses("primary", "md", "mt-6")}>Try again</button>
    </div>
  );
}
