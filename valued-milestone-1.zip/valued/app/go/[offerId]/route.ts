import { NextResponse } from "next/server";
import { getOfferById } from "@/lib/catalog";
import { getSafeOutboundUrl } from "@/lib/outbound";

/**
 * Outbound redirect. The URL is looked up server-side from the offer id and checked against the
 * retailer's own domain, so this can never be used as an open redirect.
 * Click recording will be added here once the database exists.
 */
export async function GET(_req: Request, { params }: { params: Promise<{ offerId: string }> }) {
  const { offerId } = await params;
  const notFound = () => new NextResponse("Not found", { status: 404, headers: { "X-Robots-Tag": "noindex" } });

  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(offerId)) return notFound();
  const found = await getOfferById(offerId);
  if (!found) return notFound();

  const target = getSafeOutboundUrl(found.offer.productUrl, [found.retailer.baseUrl]);
  if (!target) return notFound();

  const res = NextResponse.redirect(target, 302);
  res.headers.set("X-Robots-Tag", "noindex");
  res.headers.set("Referrer-Policy", "no-referrer");
  return res;
}
