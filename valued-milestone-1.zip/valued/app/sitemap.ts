import type { MetadataRoute } from "next";
import { getAllProducts } from "@/lib/catalog";
import { siteUrl } from "@/lib/site";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const products = await getAllProducts();
  const pages = ["", "/products", "/deals", "/about", "/contact", "/privacy", "/terms", "/affiliate-disclosure"];
  return [
    ...pages.map((p) => ({ url: `${siteUrl}${p}` })),
    ...products.map((p) => ({ url: `${siteUrl}/product/${p.slug}` })),
  ];
}
