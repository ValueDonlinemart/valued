import type { Metadata } from "next";
import { ComingSoon } from "@/components/coming-soon";

export const metadata: Metadata = { title: "AI Assistant (coming soon)", robots: { index: false } };

export default function Page() {
  return <ComingSoon title="AI Assistant" summary="Describe your budget and needs and get recommendations grounded in the ValueD catalogue. It will never invent products, prices or stock." needs={["The core comparison features (done) and a persisted catalogue", "A server-side LLM API key", "Request validation and rate limiting"]} />;
}
