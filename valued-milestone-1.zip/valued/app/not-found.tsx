import { ButtonLink } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-20 sm:px-6">
      <h1 className="text-3xl font-bold">Page not found</h1>
      <p className="mt-3 text-ink-soft">That page or product does not exist. It may have been moved or removed.</p>
      <div className="mt-6 flex gap-3">
        <ButtonLink href="/products">Browse products</ButtonLink>
        <ButtonLink href="/" variant="secondary">Back to home</ButtonLink>
      </div>
    </div>
  );
}
