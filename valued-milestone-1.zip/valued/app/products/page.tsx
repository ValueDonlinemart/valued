import type { Metadata } from "next";
import { CatalogueView } from "@/components/catalogue-view";

export const metadata: Metadata = {
  title: "Products",
  description: "Browse products and compare retailer offers on ValueD.",
  alternates: { canonical: "/products" },
};

export default async function ProductsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  return <CatalogueView basePath="/products" rawParams={await searchParams} requireQuery={false} />;
}
