import type { Metadata } from "next";
import { InfoPage } from "@/components/info-page";

export const metadata: Metadata = { title: "Contact", alternates: { canonical: "/contact" } };

export default function ContactPage() {
  return (
    <InfoPage title="Contact" draft>
      <p>Contact details have not been published yet.</p>
      <ul>
        <li>Support email: [to be added]</li>
        <li>Business address: [to be added]</li>
      </ul>
      <p>A contact form will only be added once a mailbox or ticketing system is in place to receive messages.</p>
    </InfoPage>
  );
}
