import type { Metadata } from "next";
import { ComingSoon } from "@/components/coming-soon";

export const metadata: Metadata = { title: "Price Tracker (coming soon)", robots: { index: false } };

export default function Page() {
  return <ComingSoon title="Price Tracker" summary="Track a product and get told when its comparable price drops below your target." needs={["User accounts (Supabase Auth)", "A database of recorded price observations", "A scheduled job that checks prices", "A configured email or push notification service"]} />;
}
