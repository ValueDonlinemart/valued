import type { Metadata } from "next";
import { InfoPage } from "@/components/info-page";

export const metadata: Metadata = { title: "Affiliate Disclosure", alternates: { canonical: "/affiliate-disclosure" } };

export default function AffiliateDisclosurePage() {
  return (
    <InfoPage title="Affiliate Disclosure" draft>
      <p>ValueD does not currently have any affiliate agreements. Links to retailers are ordinary links, and the retailers shown in the demo catalogue are fictional.</p>
      <h2>If this changes</h2>
      <p>If ValueD joins affiliate programmes, we may earn a commission when you buy through certain links, at no extra cost to you. Affiliate links will be marked with a rel attribute that identifies them as sponsored, and this page will list the programmes.</p>
      <p>Commissions will not change how offers are ranked. Rankings depend on product match and comparable price, as explained on each product page. Any paid placement will be visibly labelled.</p>
    </InfoPage>
  );
}
