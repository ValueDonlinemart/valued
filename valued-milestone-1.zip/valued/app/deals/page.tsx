import type { Metadata } from "next";
import { ProductCard } from "@/components/product-card";
import { SourceNotice } from "@/components/source-notice";
import { getDataSourceStatus, getDeals } from "@/lib/catalog";

export const metadata: Metadata = { title: "Deals", description: "Products with confirmed discounts on their best-ranked offer.", alternates: { canonical: "/deals" } };

export default async function DealsPage() {
  const [deals, status] = await Promise.all([getDeals(24), getDataSourceStatus()]);
  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <h1 className="text-3xl font-bold sm:text-4xl">Deals</h1>
      <p className="mt-2 max-w-2xl text-ink-soft">Products whose best-ranked offer includes a confirmed discount. Bank and exchange offers are not counted here because they depend on the buyer.</p>
      <div className="mt-5"><SourceNotice status={status} /></div>
      {deals.length === 0 ? (
        <p className="mt-8 text-muted">No confirmed discounts are recorded right now.</p>
      ) : (
        <ul className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {deals.map((s) => <li key={s.product.id} className="flex"><div className="flex-1"><ProductCard summary={s} /></div></li>)}
        </ul>
      )}
    </div>
  );
}
