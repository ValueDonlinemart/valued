import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { OfferComparison } from "@/components/offer-comparison";
import { ProductCard } from "@/components/product-card";
import { ProductThumb } from "@/components/product-thumb";
import { SourceNotice } from "@/components/source-notice";
import { VERIFY_NOTICE } from "@/lib/constants";
import {
  getCategories, getDataSourceStatus, getProductBySlug, getRankedOffers, getSimilarProducts,
} from "@/lib/catalog";
import { explainRanking } from "@/lib/ranking";

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export async function generateMetadata({ params }: Pick<Props, "params">): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "Product not found", robots: { index: false } };
  return {
    title: `${product.name} price comparison`,
    description: `Compare retailer offers for the ${product.name} (model ${product.modelNumber}) on ValueD.`,
    alternates: { canonical: `/product/${product.slug}` },
  };
}

export default async function ProductPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const sp = await searchParams;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  // An unknown ?variant= value falls back to the first variant instead of erroring.
  const rawVariant = Array.isArray(sp.variant) ? sp.variant[0] : sp.variant;
  const variant = product.variants.find((v) => v.id === rawVariant) ?? product.variants[0] ?? null;

  const [ranked, status, categories, similar] = await Promise.all([
    getRankedOffers(product, variant?.id ?? null),
    getDataSourceStatus(),
    getCategories(),
    getSimilarProducts(product, 3),
  ]);
  const category = categories.find((c) => c.slug === product.categorySlug);
  const specs = Object.entries(product.specifications);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <nav aria-label="Breadcrumb" className="text-sm text-muted">
        <ol className="flex flex-wrap gap-1">
          <li><Link href="/products" className="underline underline-offset-4">Products</Link><span aria-hidden="true"> / </span></li>
          {category ? <li><Link href={`/products?category=${category.slug}`} className="underline underline-offset-4">{category.name}</Link><span aria-hidden="true"> / </span></li> : null}
          <li aria-current="page">{product.name}</li>
        </ol>
      </nav>

      <div className="mt-6 grid gap-8 lg:grid-cols-[22rem_1fr]">
        <ProductThumb product={product} className="h-64 lg:h-80" />
        <div>
          <h1 className="text-3xl font-bold sm:text-4xl">{product.name}</h1>
          <p className="mt-2 text-ink-soft">{product.brand}, model {product.modelNumber}</p>
          <p className="mt-4 max-w-prose text-ink-soft">{product.description}</p>

          {product.variants.length > 0 ? (
            <div className="mt-6">
              <p id="variant-label" className="text-sm font-medium">Configuration</p>
              <ul aria-labelledby="variant-label" className="mt-2 flex flex-wrap gap-2">
                {product.variants.map((v) => {
                  const active = v.id === variant?.id;
                  return (
                    <li key={v.id}>
                      <Link href={`/product/${product.slug}?variant=${v.id}`} aria-current={active ? "true" : undefined} className={`inline-block rounded-lg border px-3 py-2 text-sm font-medium ${active ? "border-brand-700 bg-brand-700 text-white" : "border-line bg-white hover:bg-mint-100"}`}>
                        {v.label}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          ) : null}
        </div>
      </div>

      <section aria-labelledby="offers" className="mt-12">
        <h2 id="offers" className="text-2xl font-bold">Compare offers{variant ? ` for ${variant.label}` : ""}</h2>
        <div className="mt-3 space-y-3">
          <SourceNotice status={status} />
          <p className="max-w-3xl text-ink-soft">{explainRanking(ranked)}</p>
          <p className="text-sm text-muted">
            Comparable total = listed price + mandatory delivery - confirmed discounts. Bank, exchange and membership offers depend on you, so they are listed separately and not counted.
          </p>
        </div>
        <div className="mt-6"><OfferComparison ranked={ranked} productName={product.name} /></div>
        <p className="mt-4 text-sm text-muted">{VERIFY_NOTICE} See our <Link href="/affiliate-disclosure" className="underline underline-offset-4">affiliate disclosure</Link>.</p>
      </section>

      {specs.length > 0 ? (
        <section aria-labelledby="specs" className="mt-12">
          <h2 id="specs" className="text-2xl font-bold">Specifications</h2>
          <dl className="mt-4 max-w-3xl divide-y divide-line rounded-xl border border-line">
            {specs.map(([k, v]) => (
              <div key={k} className="grid grid-cols-3 gap-3 px-4 py-3 text-sm"><dt className="font-medium">{k}</dt><dd className="col-span-2 text-ink-soft">{v}</dd></div>
            ))}
          </dl>
          <p className="mt-2 text-sm text-muted">Specifications are summarised. Confirm details with the manufacturer or retailer.</p>
        </section>
      ) : null}

      {similar.length > 0 ? (
        <section aria-labelledby="similar" className="mt-12">
          <h2 id="similar" className="text-2xl font-bold">Similar products</h2>
          <ul className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {similar.map((s) => <li key={s.product.id} className="flex"><div className="flex-1"><ProductCard summary={s} /></div></li>)}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
