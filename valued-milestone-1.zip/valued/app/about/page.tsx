import type { Metadata } from "next";
import { InfoPage } from "@/components/info-page";

export const metadata: Metadata = { title: "About", alternates: { canonical: "/about" } };

export default function AboutPage() {
  return (
    <InfoPage title="About ValueD">
      <p>ValueD helps shoppers in India compare product offers across supported online retailers and make informed purchasing decisions. The tagline is Compare Smart. Buy Better.</p>
      <h2>What works today</h2>
      <p>This is an early prototype. It currently runs on demonstration data, which is clearly labelled wherever it appears. Prices shown are illustrative and are not live offers.</p>
      <h2>How we compare</h2>
      <p>We add the listed price and any mandatory delivery charge, then subtract only discounts that apply to every buyer. Bank, exchange and membership offers depend on the buyer, so we show them separately. Listings for a different model, or that are out of stock, are left out of the ranking.</p>
      <h2>Who we are</h2>
      <p>[Company name, location and team details to be added before launch.]</p>
    </InfoPage>
  );
}
