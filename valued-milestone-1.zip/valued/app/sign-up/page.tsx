import type { Metadata } from "next";
import { ComingSoon } from "@/components/coming-soon";

export const metadata: Metadata = { title: "Join Free (coming soon)", robots: { index: false } };

export default function Page() {
  return <ComingSoon title="Join Free" summary="Accounts are not available yet. Joining will unlock watchlists and price alerts once they are built." needs={["Supabase project and Auth configuration", "Sign-in, sign-up and account settings pages"]} />;
}
