import Link from "next/link";
import { CategoryIcon } from "@/components/category-icon";
import { HeroLedger } from "@/components/hero-ledger";
import { ProductCard } from "@/components/product-card";
import { SearchForm } from "@/components/search-form";
import { SourceNotice } from "@/components/source-notice";
import { ButtonLink } from "@/components/ui/button";
import {
  defaultVariantId, getCategories, getDataSourceStatus, getDeals, getProductBySlug, getProductSummaries, getRankedOffers,
} from "@/lib/catalog";
import { POPULAR_SEARCHES } from "@/lib/constants";

export default async function HomePage() {
  const [categories, summaries, deals, status, iphone] = await Promise.all([
    getCategories(), getProductSummaries(), getDeals(4), getDataSourceStatus(), getProductBySlug("iphone-15"),
  ]);
  const variantId = iphone ? defaultVariantId(iphone) : null;
  const ranked = iphone ? await getRankedOffers(iphone, variantId) : [];
  const variantLabel = iphone?.variants.find((v) => v.id === variantId)?.label ?? null;
  const countFor = (slug: string) => summaries.filter((s) => s.product.categorySlug === slug).length;

  return (
    <>
      {/* Hero */}
      <section className="border-b border-line bg-mint">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:items-center lg:py-20">
          <div>
            <h1 className="font-display text-4xl font-bold leading-[1.05] sm:text-5xl lg:text-6xl">Compare Smart. Buy Better.</h1>
            <p className="mt-5 max-w-xl text-lg text-ink-soft">
              Find the right product at the right price. Compare offers across supported shopping platforms and make confident buying decisions with ValueD.
            </p>
            <div className="mt-8 max-w-xl"><SearchForm id="hero-search" size="lg" /></div>
            <div className="mt-4 flex flex-wrap items-center gap-2 text-sm">
              <span className="text-muted">Popular searches:</span>
              {POPULAR_SEARCHES.map((s) => (
                <Link key={s} href={`/search?q=${encodeURIComponent(s)}`} className="rounded-full border border-line bg-white px-3 py-1 hover:bg-brand-50">{s}</Link>
              ))}
            </div>
            <div className="mt-6"><ButtonLink href="/products" variant="secondary" size="lg">Explore products</ButtonLink></div>
          </div>
          {iphone ? <HeroLedger product={iphone} variantLabel={variantLabel} ranked={ranked} /> : null}
        </div>
      </section>

      {/* Categories */}
      <section aria-labelledby="categories" className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <h2 id="categories" className="text-3xl font-bold">Popular categories</h2>
        <ul className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((c) => (
            <li key={c.slug}>
              <Link href={`/products?category=${c.slug}`} className="flex items-center gap-4 rounded-xl border border-line bg-white p-4 hover:border-brand-700 hover:bg-mint">
                <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-mint-100 text-brand-700"><CategoryIcon slug={c.slug} /></span>
                <span>
                  <span className="block font-semibold text-forest">{c.name}</span>
                  <span className="block text-sm text-muted">{countFor(c.slug)} {countFor(c.slug) === 1 ? "product" : "products"}</span>
                </span>
              </Link>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-sm text-muted">Fashion will be added once a catalogue is available.</p>
      </section>

      {/* Deals */}
      <section aria-labelledby="deals" className="bg-mint py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <h2 id="deals" className="text-3xl font-bold">Best available deals</h2>
            <Link href="/deals" className="font-medium text-brand-800 underline underline-offset-4">See all deals</Link>
          </div>
          <div className="mt-4"><SourceNotice status={status} /></div>
          {deals.length > 0 ? (
            <ul className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {deals.map((s) => <li key={s.product.id} className="flex"><div className="flex-1"><ProductCard summary={s} /></div></li>)}
            </ul>
          ) : (
            <p className="mt-6 text-muted">No confirmed discounts are recorded right now.</p>
          )}
        </div>
      </section>

      {/* How it works */}
      <section aria-labelledby="how" className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <h2 id="how" className="text-3xl font-bold">How it works</h2>
        <ol className="mt-8 grid gap-8 md:grid-cols-3">
          {[
            ["Search for a product", "Type a name, brand or model number, or browse a category."],
            ["Compare available retailer offers", "See each offer's listed price, delivery and confirmed discounts added up into one comparable total."],
            ["Choose the offer that fits", "Offers for the wrong model or out of stock are set aside, and bank or exchange offers are shown separately."],
          ].map(([title, body], i) => (
            <li key={title} className="flex gap-4">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-forest font-display font-bold text-white" aria-hidden="true">{i + 1}</span>
              <div><h3 className="text-lg font-semibold">{title}</h3><p className="mt-1 text-ink-soft">{body}</p></div>
            </li>
          ))}
        </ol>
      </section>

      {/* AI assistant */}
      <section aria-labelledby="ai" className="on-dark bg-forest py-16 text-brand-100">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 sm:px-6 md:flex-row md:items-center md:justify-between">
          <div className="max-w-2xl">
            <h2 id="ai" className="!text-white text-3xl font-bold">Not sure what to buy?</h2>
            <p className="mt-3 text-lg">Tell ValueD your budget and requirements to discover products that match your needs.</p>
            <p className="mt-2 text-sm">The assistant is not available yet. It will only recommend products from the ValueD catalogue.</p>
          </div>
          <ButtonLink href="/ai-assistant" variant="onDark" size="lg">See what is planned</ButtonLink>
        </div>
      </section>

      {/* Benefits: only what exists is described as available */}
      <section aria-labelledby="benefits" className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <h2 id="benefits" className="text-3xl font-bold">What ValueD does</h2>
        <div className="mt-8 grid gap-10 md:grid-cols-2">
          <div>
            <h3 className="text-xl font-semibold">Available now</h3>
            <dl className="mt-4 space-y-4">
              <div><dt className="font-semibold">Product comparison</dt><dd className="text-ink-soft">Compare offers for the same model and configuration side by side.</dd></div>
              <div><dt className="font-semibold">Transparent pricing</dt><dd className="text-ink-soft">Every total shows how it was calculated. Unknown delivery costs are flagged, never assumed to be free.</dd></div>
            </dl>
          </div>
          <div>
            <h3 className="text-xl font-semibold">Planned, not available yet</h3>
            <dl className="mt-4 space-y-4">
              <div><dt className="font-semibold">Price history</dt><dd className="text-ink-soft">Needs real price records collected over time.</dd></div>
              <div><dt className="font-semibold">Price alerts</dt><dd className="text-ink-soft">Needs accounts, scheduled checks and a notification service.</dd></div>
              <div><dt className="font-semibold">Shopping recommendations</dt><dd className="text-ink-soft">Needs the AI assistant and a larger catalogue.</dd></div>
            </dl>
          </div>
        </div>
      </section>
    </>
  );
}
