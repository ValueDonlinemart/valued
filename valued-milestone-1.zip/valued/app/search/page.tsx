import type { Metadata } from "next";
import { CatalogueView } from "@/components/catalogue-view";

// Search result pages are never indexed: they are thin and nearly infinite.
export const metadata: Metadata = { title: "Search products", robots: { index: false, follow: true } };

export default async function SearchPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  return <CatalogueView basePath="/search" rawParams={await searchParams} requireQuery />;
}
