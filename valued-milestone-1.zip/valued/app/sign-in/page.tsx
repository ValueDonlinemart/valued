import type { Metadata } from "next";
import { ComingSoon } from "@/components/coming-soon";

export const metadata: Metadata = { title: "Sign In (coming soon)", robots: { index: false } };

export default function Page() {
  return <ComingSoon title="Sign In" summary="Accounts are not available yet. The catalogue is open to everyone without signing in." needs={["Supabase project and Auth configuration", "Sign-in, sign-up and account settings pages"]} />;
}
