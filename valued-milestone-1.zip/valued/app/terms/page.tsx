import type { Metadata } from "next";
import { InfoPage } from "@/components/info-page";

export const metadata: Metadata = { title: "Terms of Service", alternates: { canonical: "/terms" } };

export default function TermsPage() {
  return (
    <InfoPage title="Terms of Service" draft>
      <h2>Information only</h2>
      <p>ValueD provides price and product information for comparison. Retailers set their own prices, stock, delivery charges and terms, and these can change at any time.</p>
      <h2>Verify before you buy</h2>
      <p>Check the final price, delivery cost, seller, warranty and return terms on the retailer's website before you buy. ValueD is not the seller and is not a party to your purchase.</p>
      <h2>Demonstration data</h2>
      <p>While the site shows data labelled as demo data, prices and offers are illustrative only.</p>
      <h2>Legal entity and governing law</h2>
      <p>[To be added before launch.]</p>
    </InfoPage>
  );
}
