import type { Metadata } from "next";
import { InfoPage } from "@/components/info-page";

export const metadata: Metadata = { title: "Privacy Policy", alternates: { canonical: "/privacy" } };

export default function PrivacyPage() {
  return (
    <InfoPage title="Privacy Policy" draft>
      <p>This describes what the current prototype does. It will be updated whenever features that collect data are added.</p>
      <h2>What the site collects now</h2>
      <ul>
        <li>No accounts exist yet, so no account data is collected.</li>
        <li>No analytics or advertising trackers are installed.</li>
        <li>Outbound clicks are not recorded yet.</li>
        <li>The hosting provider may keep standard server logs, such as IP address and requested page, for security and operations.</li>
      </ul>
      <h2>What will change</h2>
      <p>When accounts, watchlists, price alerts, click analytics or AI features are added, this page must describe the data collected, why, how long it is kept, and how to request deletion. Consent controls must be added for any optional analytics or notifications.</p>
      <h2>Controller and contact</h2>
      <p>[Legal entity name and contact details to be added before launch.]</p>
    </InfoPage>
  );
}
